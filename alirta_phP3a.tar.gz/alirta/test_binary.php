<?php
/**
 * 简化的 protobuf 测试 - 直接发送二进制数据测试服务
 */

/**
 * 创建模拟的 protobuf 请求数据
 */
function createMockRtaRequest($type = 'normal') {
    switch ($type) {
        case 'ping':
            // 模拟 ping 请求的 protobuf 结构
            // Field 1 (user_id): "2088802123844356"
            // Field 2 (one_id): "test_one_id"  
            // Field 3 (req_id): "test-ping-request"
            // Field 7 (request_time): 1718356326000
            // Field 8 (is_ping): true
            $data = '';
            $data .= "\x0a" . chr(strlen('2088802123844356')) . '2088802123844356'; // user_id
            $data .= "\x12" . chr(strlen('test_one_id')) . 'test_one_id'; // one_id  
            $data .= "\x1a" . chr(strlen('test-ping-request')) . 'test-ping-request'; // req_id
            $data .= "\x38\x80\x90\xde\x8d\xdf\x62"; // request_time (varint)
            $data .= "\x40\x01"; // is_ping = true
            return $data;
            
        case 'normal':
            // 模拟正常请求的 protobuf 结构
            $data = '';
            $data .= "\x0a" . chr(strlen('2088802123844356')) . '2088802123844356'; // user_id
            $data .= "\x12" . chr(strlen('test_one_id')) . 'test_one_id'; // one_id
            $data .= "\x1a" . chr(strlen('780dea69-7ea6-4829-a931-a6a44a1dd56a')) . '780dea69-7ea6-4829-a931-a6a44a1dd56a'; // req_id
            $data .= "\x38\x80\x90\xde\x8d\xdf\x62"; // request_time
            $data .= "\x40\x00"; // is_ping = false
            
            // 添加设备信息 (field 6)
            $deviceInfo = '';
            $deviceInfo .= "\x08\x02"; // os_type = ANDROID (2)
            $deviceInfo .= "\x1a" . chr(strlen('10.3.20.8100')) . '10.3.20.8100'; // alipay_client_version
            
            // 添加设备ID
            $deviceId = '';
            $deviceId .= "\x08\x01"; // type = OAID_HASH (1)
            $deviceId .= "\x12" . chr(strlen('oaid_hash_to_bid_1')) . 'oaid_hash_to_bid_1'; // value
            
            $deviceInfo .= "\x22" . chr(strlen($deviceId)) . $deviceId; // device_id field
            
            $data .= "\x32" . chr(strlen($deviceInfo)) . $deviceInfo; // device_info field
            
            // 添加 RTA 请求信息 (field 4)
            $rtaReqInfo = '';
            $rtaReqInfo .= "\x0a" . chr(strlen('rta_id_1')) . 'rta_id_1'; // rta_id
            $rtaReqInfo .= "\x12" . chr(strlen('100492304')) . '100492304'; // ad_id
            
            $data .= "\x22" . chr(strlen($rtaReqInfo)) . $rtaReqInfo; // rta_req_info field
            
            return $data;
            
        default:
            return '';
    }
}

/**
 * 发送测试请求
 */
function sendTestRequest($url, $data, $testName) {
    echo "\n=== {$testName} ===\n";
    echo "发送时间: " . date('Y-m-d H:i:s') . "\n";
    echo "数据长度: " . strlen($data) . " bytes\n";
    echo "数据hex前50字节: " . bin2hex(substr($data, 0, 50)) . "\n";
    
    $startTime = microtime(true);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-protobuf; charset=UTF-8',
            'Accept: application/x-protobuf'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
    
    curl_close($ch);
    
    $endTime = microtime(true);
    $processTime = ($endTime - $startTime) * 1000;
    
    echo "HTTP状态码: {$httpCode}\n";
    echo "总耗时: " . round($processTime, 2) . "ms\n";
    echo "网络耗时: " . round($totalTime, 2) . "ms\n";
    
    if (!empty($error)) {
        echo "❌ CURL错误: {$error}\n";
        return false;
    }
    
    if ($httpCode !== 200) {
        echo "❌ HTTP错误 ({$httpCode})\n";
        echo "响应内容: " . substr($response, 0, 200) . "\n";
        return false;
    }
    
    echo "响应长度: " . strlen($response) . " bytes\n";
    
    if (strlen($response) > 0) {
        echo "响应hex前50字节: " . bin2hex(substr($response, 0, 50)) . "\n";
        
        // 简单检查响应是否像 protobuf
        if (ord($response[0]) > 0 && ord($response[0]) < 255) {
            echo "✅ 收到有效的 protobuf 响应\n";
        } else {
            echo "⚠️  响应可能不是 protobuf 格式\n";
            echo "响应内容前100字符: " . substr($response, 0, 100) . "\n";
        }
    } else {
        echo "⚠️  收到空响应\n";
    }
    
    return true;
}

// 主测试
$rtaUrl = 'http://ads.vivemall.com/alirta/rta_proxy_binary.php';

echo "🧪 简化 protobuf 测试\n";
echo "目标地址: {$rtaUrl}\n";
echo "测试时间: " . date('Y-m-d H:i:s') . "\n";
echo "注意: 使用手工构造的 protobuf 数据测试服务解析能力\n";

$tests = [
    'ping' => 'Ping 请求测试',
    'normal' => '正常 RTA 请求测试'
];

$results = [];

foreach ($tests as $testType => $testName) {
    $data = createMockRtaRequest($testType);
    $success = sendTestRequest($rtaUrl, $data, $testName);
    $results[$testType] = $success;
    sleep(1); // 间隔1秒
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "测试总结:\n";
foreach ($results as $testType => $success) {
    $status = $success ? "✅ 成功" : "❌ 失败";
    echo "{$tests[$testType]}: {$status}\n";
}

$passedCount = array_sum($results);
echo "\n通过率: {$passedCount}/" . count($results) . "\n";

if ($passedCount > 0) {
    echo "\n🎉 服务基本功能正常！\n";
    echo "建议查看日志了解详细处理过程: tail -f /tmp/rta_proxy.log\n";
} else {
    echo "\n❌ 服务可能存在问题，请检查日志\n";
}
?>