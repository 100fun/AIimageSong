<?php
/**
 * RTA 代理服务 - 最终版本
 * 修复网络连接问题
 */

// 设置响应头
header('Content-Type: application/x-protobuf; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理 OPTIONS 预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 配置区域
const CONFIG = [
    'vip_rta_url' => 'https://d-rta.vtd.vip.com/rta/Isps_vip3/v1',
    'timeout' => 45, // 请求超时时间（毫秒）
    'connect_timeout' => 5000, // 连接超时时间（毫秒）
    'log_enabled' => true,
    'log_file' => '/tmp/rta_proxy.log',
    'token_mapping' => [
        'rta_id_1' => 'ali_install',
        'rta_id_2' => 'ali_laxin', 
        'rta_id_3' => 'ali_lahuo',
        'default' => 'ali_install'
    ]
];

/**
 * 记录日志
 */
function writeLog($message, $level = 'INFO') {
    if (!CONFIG['log_enabled']) return;
    
    $timestamp = date('Y-m-d H:i:s.u');
    $logMessage = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    file_put_contents(CONFIG['log_file'], $logMessage, FILE_APPEND | LOCK_EX);
}

/**
 * 获取客户端IP
 */
function getClientIP() {
    $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ips = explode(',', $_SERVER[$key]);
            return trim($ips[0]);
        }
    }
    return 'unknown';
}

/**
 * 简单的 protobuf 解析 - 提取基本字段
 */
function parseProtobufBasicFields($data) {
    $result = [
        'user_id' => '',
        'one_id' => '',
        'req_id' => '',
        'request_time' => 0,
        'is_ping' => false,
        'device_ids' => [],
        'rta_req_info' => []
    ];
    
    $pos = 0;
    $len = strlen($data);
    
    while ($pos < $len) {
        if ($pos >= $len) break;
        
        $header = ord($data[$pos++]);
        $fieldNumber = $header >> 3;
        $wireType = $header & 0x07;
        
        switch ($fieldNumber) {
            case 1: // user_id (string)
                if ($wireType == 2) {
                    $strLen = ord($data[$pos++]);
                    if ($pos + $strLen <= $len) {
                        $result['user_id'] = substr($data, $pos, $strLen);
                        $pos += $strLen;
                    }
                }
                break;
                
            case 2: // one_id (string)
                if ($wireType == 2) {
                    $strLen = ord($data[$pos++]);
                    if ($pos + $strLen <= $len) {
                        $result['one_id'] = substr($data, $pos, $strLen);
                        $pos += $strLen;
                    }
                }
                break;
                
            case 3: // req_id (string)
                if ($wireType == 2) {
                    $strLen = ord($data[$pos++]);
                    if ($pos + $strLen <= $len) {
                        $result['req_id'] = substr($data, $pos, $strLen);
                        $pos += $strLen;
                    }
                }
                break;
                
            case 7: // request_time (int64)
                if ($wireType == 0) {
                    $value = 0;
                    $shift = 0;
                    while ($pos < $len && $shift < 64) {
                        $byte = ord($data[$pos++]);
                        $value |= ($byte & 0x7F) << $shift;
                        if (($byte & 0x80) == 0) break;
                        $shift += 7;
                    }
                    $result['request_time'] = $value;
                }
                break;
                
            case 8: // is_ping (bool)
                if ($wireType == 0) {
                    $result['is_ping'] = ord($data[$pos++]) != 0;
                }
                break;
                
            default:
                // 跳过未知字段
                if ($wireType == 0) { // varint
                    while ($pos < $len && (ord($data[$pos]) & 0x80) != 0) $pos++;
                    if ($pos < $len) $pos++;
                } elseif ($wireType == 2) { // length-delimited
                    if ($pos < $len) {
                        $skipLen = ord($data[$pos++]);
                        $pos += $skipLen;
                    }
                } else {
                    $pos++; // 其他类型，简单跳过
                }
                break;
        }
    }
    
    return $result;
}

/**
 * 创建简单的 protobuf 响应
 */
function createProtobufResponse($reqId, $retCode = 0, $retMsg = 'success', $rtaData = []) {
    $response = '';
    
    // Field 1: ret_code (int32)
    $response .= "\x08" . chr($retCode);
    
    // Field 2: req_id (string)
    if ($reqId) {
        $response .= "\x12" . chr(strlen($reqId)) . $reqId;
    }
    
    // Field 3: response_time (int64) - 当前时间戳（毫秒）
    $responseTime = time() * 1000;
    $timeBytes = '';
    while ($responseTime > 0) {
        $byte = $responseTime & 0x7F;
        $responseTime >>= 7;
        if ($responseTime > 0) $byte |= 0x80;
        $timeBytes .= chr($byte);
    }
    $response .= "\x18" . $timeBytes;
    
    // Field 4: process_time_ms (int32) - 固定1ms
    $response .= "\x20\x01";
    
    // Field 5: ret_msg (string)
    $response .= "\x2a" . chr(strlen($retMsg)) . $retMsg;
    
    // Field 6: rta_data (repeated)
    foreach ($rtaData as $data) {
        $rtaDataBytes = '';
        
        // rta_req_info
        if (isset($data['rta_id'])) {
            $rtaReqInfo = '';
            $rtaReqInfo .= "\x0a" . chr(strlen($data['rta_id'])) . $data['rta_id']; // rta_id
            if (isset($data['ad_id'])) {
                $rtaReqInfo .= "\x12" . chr(strlen($data['ad_id'])) . $data['ad_id']; // ad_id
            }
            $rtaDataBytes .= "\x0a" . chr(strlen($rtaReqInfo)) . $rtaReqInfo;
        }
        
        // is_bid
        $rtaDataBytes .= "\x10" . chr(isset($data['is_bid']) && $data['is_bid'] ? 1 : 0);
        
        $response .= "\x32" . chr(strlen($rtaDataBytes)) . $rtaDataBytes;
    }
    
    return $response;
}

/**
 * 将解析的请求转换为唯品会格式
 */
function convertToVipRequest($parsedRequest) {
    $vipRequest = [
        'v' => '1.0',
        'id' => $parsedRequest['req_id'] ?: uniqid('req_', true),
        'adReqs' => []
    ];
    
    // 处理ping请求
    if ($parsedRequest['is_ping']) {
        $vipRequest['test'] = 1;
    }
    
    // 添加默认广告请求
    foreach (CONFIG['token_mapping'] as $rtaId => $token) {
        if ($rtaId !== 'default') {
            $vipRequest['adReqs'][] = [
                'token' => $token,
                'adId' => 100001
            ];
        }
    }
    
    // 如果没有配置映射，使用默认
    if (empty($vipRequest['adReqs'])) {
        $vipRequest['adReqs'][] = [
            'token' => CONFIG['token_mapping']['default'],
            'adId' => 100001
        ];
    }
    
    return $vipRequest;
}

/**
 * 发送请求到唯品会RTA服务（修复网络超时问题）
 */
function sendToVipRTA($vipRequest) {
    $ch = curl_init();
    
    curl_setopt_array($ch, [
        CURLOPT_URL => CONFIG['vip_rta_url'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT_MS => CONFIG['timeout'] * 1000, // 转换为毫秒
        CURLOPT_CONNECTTIMEOUT_MS => CONFIG['connect_timeout'], // 连接超时
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Alipay-RTA-Proxy/1.0.3',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($vipRequest, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json; charset=UTF-8',
            'Accept: application/json',
            'Connection: keep-alive'
        ],
        CURLOPT_DNS_CACHE_TIMEOUT => 300, // DNS 缓存5分钟
        CURLOPT_FRESH_CONNECT => false,
        CURLOPT_FORBID_REUSE => false
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
    
    curl_close($ch);
    
    if ($response === false || !empty($error)) {
        throw new Exception("CURL Error: " . $error);
    }
    
    return [
        'http_code' => $httpCode,
        'response' => $response,
        'total_time_ms' => $totalTime
    ];
}

/**
 * 主处理函数
 */
function handleRequest() {
    $startTime = microtime(true);
    $clientIP = getClientIP();
    
    try {
        writeLog("收到RTA请求 - IP: {$clientIP}");
        
        // 获取原始请求数据
        $rawInput = file_get_contents('php://input');
        if (empty($rawInput)) {
            throw new Exception('Empty request body');
        }
        
        writeLog("请求数据长度: " . strlen($rawInput) . " bytes");
        
        // 解析基本 protobuf 字段
        $parsedRequest = parseProtobufBasicFields($rawInput);
        writeLog("解析基本字段成功 - req_id: " . $parsedRequest['req_id'] . ", is_ping: " . ($parsedRequest['is_ping'] ? 'true' : 'false'));
        
        // 处理ping请求
        if ($parsedRequest['is_ping']) {
            writeLog("处理ping请求");
            $response = createProtobufResponse($parsedRequest['req_id'], 0, 'pong');
            echo $response;
            writeLog("ping响应完成");
            return;
        }
        
        // 转换为唯品会请求格式
        $vipRequest = convertToVipRequest($parsedRequest);
        writeLog("转换为唯品会请求，包含 " . count($vipRequest['adReqs']) . " 个广告请求");
        
        // 发送到唯品会RTA服务
        $vipResponse = sendToVipRTA($vipRequest);
        writeLog("唯品会响应 - HTTP: {$vipResponse['http_code']}, 耗时: " . round($vipResponse['total_time_ms'], 2) . "ms");
        
        if ($vipResponse['http_code'] !== 200) {
            throw new Exception("VIP RTA service returned HTTP {$vipResponse['http_code']}");
        }
        
        // 解析唯品会响应并构造返回数据
        $vipData = json_decode($vipResponse['response'], true);
        $rtaData = [];
        
        if ($vipData && isset($vipData['bidResp']['adResps'])) {
            foreach ($vipData['bidResp']['adResps'] as $adResp) {
                $rtaData[] = [
                    'rta_id' => array_search($adResp['token'], CONFIG['token_mapping']) ?: $adResp['token'],
                    'ad_id' => strval($adResp['adId'] ?? '100001'),
                    'is_bid' => ($adResp['ac'] === 'y')
                ];
            }
            writeLog("构造了 " . count($rtaData) . " 条RTA响应数据");
        }
        
        // 创建并返回 protobuf 响应
        $response = createProtobufResponse(
            $parsedRequest['req_id'], 
            ($vipData && $vipData['errno'] == 0) ? 0 : 1,
            $vipData['msg'] ?? 'success',
            $rtaData
        );
        
        http_response_code(200);
        echo $response;
        
        $totalTime = round((microtime(true) - $startTime) * 1000, 2);
        writeLog("请求完成 - 总耗时: {$totalTime}ms, 响应长度: " . strlen($response) . " bytes");
        
    } catch (Exception $e) {
        writeLog("错误: " . $e->getMessage(), 'ERROR');
        
        // 返回错误响应
        $response = createProtobufResponse(
            isset($parsedRequest['req_id']) ? $parsedRequest['req_id'] : 'unknown', 
            1, 
            'Internal Server Error'
        );
        
        http_response_code(200);
        echo $response;
    }
}

/**
 * 健康检查
 */
function healthCheck() {
    header('Content-Type: application/json; charset=utf-8');
    
    $status = [
        'status' => 'ok',
        'timestamp' => date('Y-m-d H:i:s'),
        'version' => '1.0.3',
        'service' => 'Alipay-VIP RTA Proxy (Production Ready)',
        'protobuf' => 'binary_parsing',
        'performance' => [
            'timeout' => CONFIG['timeout'] . 'ms',
            'connect_timeout' => CONFIG['connect_timeout'] . 'ms'
        ],
        'config' => [
            'vip_url' => CONFIG['vip_rta_url'],
            'tokens' => array_keys(CONFIG['token_mapping'])
        ]
    ];
    
    echo json_encode($status, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

// 主程序入口
if (isset($_GET['health'])) {
    healthCheck();
} else {
    handleRequest();
}
?>