#!/bin/bash

echo "RTA 服务快速测试"
echo "=================="

# 设置 RTA 服务地址
RTA_URL="http://ads.vivemall.com/alirta/rta_proxy.php"

echo "1. 测试基础连接..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$RTA_URL?health")
if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ 基础连接正常 (HTTP $HTTP_CODE)"
else
    echo "❌ 基础连接失败 (HTTP $HTTP_CODE)"
    exit 1
fi

echo ""
echo "2. 测试健康检查接口..."
HEALTH_RESPONSE=$(curl -s "$RTA_URL?health")
if echo "$HEALTH_RESPONSE" | grep -q '"status":"ok"'; then
    echo "✅ 健康检查通过"
    echo "配置信息:"
    echo "$HEALTH_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$HEALTH_RESPONSE"
else
    echo "❌ 健康检查失败"
    echo "响应: $HEALTH_RESPONSE"
fi

echo ""
echo "3. 测试 protobuf 处理..."
# 发送一个简单的 POST 请求测试 protobuf 处理能力
TEST_RESPONSE=$(curl -s -X POST \
    -H "Content-Type: application/x-protobuf; charset=UTF-8" \
    -d "invalid_protobuf_data" \
    "$RTA_URL")

if [ $? -eq 0 ]; then
    echo "✅ protobuf 处理模块工作正常"
    echo "注意: 这是预期的错误响应，因为我们发送了无效数据"
else
    echo "❌ protobuf 处理模块异常"
fi

echo ""
echo "4. 检查日志文件..."
if [ -f "/tmp/rta_proxy.log" ]; then
    echo "✅ 日志文件存在"
    echo "最近5条日志:"
    tail -5 /tmp/rta_proxy.log
else
    echo "⚠️  日志文件不存在或无法访问"
fi

echo ""
echo "=================="
echo "快速测试完成"
echo ""
echo "下一步:"
echo "1. 运行完整测试: php test_rta_advanced.php"
echo "2. 实时监控日志: tail -f /tmp/rta_proxy.log"
echo "3. 配置 token 映射关系到实际的 rta_id"