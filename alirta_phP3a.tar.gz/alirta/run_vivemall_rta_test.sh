#!/bin/bash

# Vivemall RTA 服务自测执行脚本
# 目标URL: https://ads.vivemall.com/alirta/rta_proxy.php

set -e

echo "🏛️  Vivemall RTA 服务自测工具"
echo "=================================="
echo "目标URL: https://ads.vivemall.com/alirta/rta_proxy.php"
echo "执行时间: $(date)"
echo "执行用户: 100fun"
echo "GitHub: https://github.com/100fun/AIimageSong/tree/master/ad-rta-test"
echo "=================================="
echo

# 检查PHP环境
if ! command -v php &> /dev/null; then
    echo "❌ 错误: 未找到PHP执行环境"
    echo "请先安装PHP (>= 7.4.0)"
    exit 1
fi

# 显示PHP信息
echo "📋 环境信息:"
echo "PHP版本: $(php -r 'echo PHP_VERSION;')"
echo "操作系统: $(uname -s)"
echo "当前时间: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo

# 检查必要的PHP扩展
echo "🔧 检查PHP扩展:"
php -r "
\$extensions = ['curl', 'json', 'openssl'];
\$missing = [];

foreach (\$extensions as \$ext) {
    if (extension_loaded(\$ext)) {
        echo '✅ ' . \$ext . ' 扩展已安装' . PHP_EOL;
    } else {
        echo '❌ ' . \$ext . ' 扩展未安装' . PHP_EOL;
        \$missing[] = \$ext;
    }
}

if (!empty(\$missing)) {
    echo PHP_EOL . '⚠️ 缺少必要扩展: ' . implode(', ', \$missing) . PHP_EOL;
    echo '请安装缺少的扩展后重新运行测试' . PHP_EOL;
    exit(1);
}
"

echo

# 执行测试
echo "🎯 开始执行 Vivemall RTA 服务测试..."
echo "这可能需要几分钟时间，请耐心等待..."
echo

# 运行测试并保存日志
LOG_FILE="vivemall_rta_test_$(date +%Y%m%d_%H%M%S).log"

if php alipay_rta_vivemall_test.php | tee "$LOG_FILE"; then
    echo
    echo "✅ 测试执行完成！"
    echo "📄 测试日志已保存到: $LOG_FILE"
else
    echo
    echo "❌ 测试执行过程中出现错误"
    echo "📄 错误日志已保存到: $LOG_FILE"
    exit 1
fi

echo
echo "📊 查看测试结果:"
echo "   - 完整日志: cat $LOG_FILE"
echo "   - 仅看结果: grep -E '(✅|❌|⚠️|📊)' $LOG_FILE"
echo
echo "🔗 相关链接:"
echo "   - GitHub项目: https://github.com/100fun/AIimageSong/tree/master/ad-rta-test"
echo "   - 支付宝RTA文档: https://adpub.alipay.com/lark/adrlark/by8otg013y0pc1o0"
echo
echo "感谢使用 Vivemall RTA 自测工具！"