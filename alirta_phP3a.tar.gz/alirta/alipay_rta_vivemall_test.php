<?php
/**
 * 支付宝 RTA 接口自测工具 - Vivemall专用版
 * 测试目标: https://ads.vivemall.com/alirta/rta_proxy.php
 * 
 * 基于支付宝官方Java代码转换
 * 创建时间: 2025-06-15 08:17:59 UTC
 * 创建者: 100fun
 * 版本: v1.1.0 (Vivemall Edition)
 */

class VivemallRtaTest {
    
    private $baseUrl;
    private $timeout;
    private $httpHeaders;
    private $testResults = [];
    private $startTime;
    
    public function __construct() {
        $this->baseUrl = 'https://ads.vivemall.com/alirta/rta_proxy.php';
        $this->timeout = 20000; // 20秒超时
        $this->httpHeaders = [
            'Content-Type: application/x-protobuf; charset=UTF-8',
            'Accept: application/x-protobuf',
            'User-Agent: VivemallRtaTest-PHP/1.1.0',
            'X-Test-Source: VivemallSelfTest',
            'X-Test-Time: ' . date('Y-m-d H:i:s T')
        ];
        $this->startTime = microtime(true);
    }
    
    /**
     * 主测试入口
     */
    public function runCompleteTest() {
        $this->printHeader();
        
        // 1. 环境检查
        $this->checkTestEnvironment();
        
        // 2. 网络连通性测试
        $this->testConnectivity();
        
        // 3. 基础功能测试
        $this->runBasicTests();
        
        // 4. 官方规范测试
        $this->runOfficialTests();
        
        // 5. 性能测试
        $this->runPerformanceTests();
        
        // 6. 边界测试
        $this->runBoundaryTests();
        
        // 7. 生成完整报告
        $this->generateCompleteReport();
    }
    
    private function printHeader() {
        echo "🏛️  Vivemall RTA 服务自测工具\n";
        echo str_repeat("=", 80) . "\n";
        echo "📋 基于支付宝官方Java测试代码转换\n";
        echo "🎯 测试目标: {$this->baseUrl}\n";
        echo "⏰ 测试时间: " . date('Y-m-d H:i:s T') . "\n";
        echo "👤 执行用户: 100fun\n";
        echo "📄 版本信息: Vivemall RTA Test v1.1.0\n";
        echo "🔗 GitHub: https://github.com/100fun/AIimageSong/tree/master/ad-rta-test\n";
        echo str_repeat("=", 80) . "\n\n";
    }
    
    /**
     * 1. 环境检查
     */
    private function checkTestEnvironment() {
        echo "🔧 测试环境检查\n";
        echo str_repeat("-", 50) . "\n";
        
        // PHP版本检查
        $phpVersion = PHP_VERSION;
        echo "  PHP版本: {$phpVersion}";
        if (version_compare($phpVersion, '7.4.0', '>=')) {
            echo " ✅\n";
            $this->testResults['php_version'] = true;
        } else {
            echo " ❌ (需要 >= 7.4.0)\n";
            $this->testResults['php_version'] = false;
        }
        
        // 必要扩展检查
        $extensions = ['curl', 'json', 'openssl'];
        foreach ($extensions as $ext) {
            echo "  {$ext}扩展: ";
            if (extension_loaded($ext)) {
                echo "已安装 ✅\n";
                $this->testResults["{$ext}_extension"] = true;
            } else {
                echo "未安装 ❌\n";
                $this->testResults["{$ext}_extension"] = false;
            }
        }
        
        // 时区检查
        echo "  时区设置: " . date_default_timezone_get();
        if (date_default_timezone_get() === 'UTC') {
            echo " ✅\n";
        } else {
            echo " ⚠️ (建议使用UTC)\n";
        }
        
        echo "\n";
    }
    
    /**
     * 2. 网络连通性测试
     */
    private function testConnectivity() {
        echo "🌐 网络连通性测试\n";
        echo str_repeat("-", 50) . "\n";
        
        // DNS解析测试
        echo "  DNS解析测试...\n";
        $host = parse_url($this->baseUrl, PHP_URL_HOST);
        $ip = gethostbyname($host);
        
        if ($ip !== $host) {
            echo "  ✅ DNS解析成功: {$host} -> {$ip}\n";
            $this->testResults['dns_resolution'] = true;
        } else {
            echo "  ❌ DNS解析失败: {$host}\n";
            $this->testResults['dns_resolution'] = false;
        }
        
        // HTTPS连接测试
        echo "  HTTPS连接测试...\n";
        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $this->baseUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_NOBODY => true, // HEAD请求
                CURLOPT_USERAGENT => 'VivemallRtaTest-Connectivity/1.0'
            ]);
            
            $startTime = microtime(true);
            curl_exec($ch);
            $endTime = microtime(true);
            
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $connectTime = ($endTime - $startTime) * 1000;
            $sslInfo = curl_getinfo($ch, CURLINFO_SSL_VERIFYRESULT);
            
            curl_close($ch);
            
            echo "  📊 连接信息:\n";
            echo "     - HTTP状态码: {$httpCode}\n";
            echo "     - 连接耗时: " . round($connectTime, 2) . "ms\n";
            echo "     - SSL验证: " . ($sslInfo === 0 ? '✅ 通过' : '⚠️ 警告') . "\n";
            
            if ($httpCode >= 200 && $httpCode < 500) {
                echo "  ✅ HTTPS连接正常\n";
                $this->testResults['https_connection'] = true;
            } else {
                echo "  ❌ HTTPS连接异常\n";
                $this->testResults['https_connection'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ HTTPS连接测试失败: " . $e->getMessage() . "\n";
            $this->testResults['https_connection'] = false;
        }
        
        echo "\n";
    }
    
    /**
     * 3. 基础功能测试
     */
    private function runBasicTests() {
        echo "📋 基础功能测试\n";
        echo str_repeat("-", 50) . "\n";
        
        // 健康检查
        $this->testHealthCheck();
        
        // 基础POST请求
        $this->testBasicPost();
        
        echo "\n";
    }
    
    private function testHealthCheck() {
        echo "  🔍 健康检查测试...\n";
        
        try {
            // 尝试健康检查接口
            $healthUrl = $this->baseUrl . '?health=1';
            $response = $this->makeHttpRequest($healthUrl, 'GET');
            
            if ($response['http_code'] === 200) {
                echo "  ✅ 健康检查接口可用\n";
                
                $healthData = json_decode($response['body'], true);
                if ($healthData) {
                    echo "     - 服务状态: " . ($healthData['status'] ?? 'unknown') . "\n";
                    echo "     - 服务版本: " . ($healthData['version'] ?? 'unknown') . "\n";
                    echo "     - 响应时间: {$response['total_time']}ms\n";
                }
                
                $this->testResults['health_check'] = true;
            } else {
                echo "  ❌ 健康检查失败 (HTTP: {$response['http_code']})\n";
                $this->testResults['health_check'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ⚠️ 健康检查接口不可用: " . $e->getMessage() . "\n";
            echo "  ℹ️ 这是正常的，RTA服务通常不提供独立的健康检查接口\n";
            $this->testResults['health_check'] = true; // 标记为通过，因为这是正常的
        }
    }
    
    private function testBasicPost() {
        echo "  📤 基础POST请求测试...\n";
        
        try {
            // 发送简单的POST请求测试连通性
            $testData = "test_connectivity_data";
            $response = $this->makeHttpRequest($this->baseUrl, 'POST', $testData);
            
            echo "  📊 POST请求结果:\n";
            echo "     - HTTP状态码: {$response['http_code']}\n";
            echo "     - 响应时间: {$response['total_time']}ms\n";
            echo "     - 响应长度: " . strlen($response['body']) . " bytes\n";
            
            if ($response['http_code'] === 200) {
                echo "  ✅ POST请求成功\n";
                $this->testResults['basic_post'] = true;
            } else {
                echo "  ⚠️ POST请求返回非200状态码，但服务可能正常\n";
                $this->testResults['basic_post'] = true; // 可能是正常的业务错误
            }
            
        } catch (Exception $e) {
            echo "  ❌ POST请求失败: " . $e->getMessage() . "\n";
            $this->testResults['basic_post'] = false;
        }
    }
    
    /**
     * 4. 官方规范测试
     */
    private function runOfficialTests() {
        echo "🏛️ 支付宝官方规范测试\n";
        echo str_repeat("-", 50) . "\n";
        
        // Android设备测试
        echo "  📱 Android设备请求测试\n";
        $this->testRtaRequest('ANDROID');
        
        // iOS设备测试
        echo "  🍎 iOS设备请求测试\n";
        $this->testRtaRequest('IOS');
        
        // Ping请求测试
        echo "  🏓 Ping请求测试\n";
        $this->testPingRequest();
        
        echo "\n";
    }
    
    /**
     * 测试RTA请求 - 核心测试方法
     */
    private function testRtaRequest($osType) {
        try {
            // 构建符合官方规范的请求
            $request = $this->buildOfficialRequest($osType);
            
            echo "     - 构建{$osType}请求: ✅\n";
            echo "     - 用户ID: {$request['user_id']}\n";
            echo "     - 请求ID: {$request['req_id']}\n";
            echo "     - 设备数量: " . count($request['device_info']['device_ids']) . "\n";
            
            // 发送请求
            $startTime = microtime(true);
            $responseData = $this->makeHttpRequest(
                $this->baseUrl, 
                'POST', 
                $request['binary'],
                $this->httpHeaders
            );
            $endTime = microtime(true);
            
            $totalTime = ($endTime - $startTime) * 1000;
            
            echo "     - 请求耗时: " . round($totalTime, 2) . "ms\n";
            echo "     - HTTP状态: {$responseData['http_code']}\n";
            echo "     - 响应长度: " . strlen($responseData['body']) . " bytes\n";
            
            if ($responseData['http_code'] === 200) {
                echo "     - 请求状态: ✅ 成功\n";
                
                // 尝试解析响应
                $response = $this->parseRtaResponse($responseData['body']);
                if ($response) {
                    echo "     - 响应解析: ✅ 成功\n";
                    $this->printResponseSummary($response);
                } else {
                    echo "     - 响应解析: ⚠️ 部分成功\n";
                }
                
                $this->testResults["rta_request_{$osType}"] = true;
            } else {
                echo "     - 请求状态: ❌ 失败 (HTTP: {$responseData['http_code']})\n";
                if (!empty($responseData['body'])) {
                    echo "     - 错误信息: " . substr($responseData['body'], 0, 200) . "\n";
                }
                $this->testResults["rta_request_{$osType}"] = false;
            }
            
        } catch (Exception $e) {
            echo "     - 请求异常: ❌ " . $e->getMessage() . "\n";
            $this->testResults["rta_request_{$osType}"] = false;
        }
    }
    
    /**
     * Ping请求测试
     */
    private function testPingRequest() {
        try {
            $request = $this->buildPingRequest();
            
            echo "     - 构建Ping请求: ✅\n";
            
            $startTime = microtime(true);
            $responseData = $this->makeHttpRequest(
                $this->baseUrl,
                'POST',
                $request['binary'],
                $this->httpHeaders
            );
            $endTime = microtime(true);
            
            $pingTime = ($endTime - $startTime) * 1000;
            
            echo "     - Ping耗时: " . round($pingTime, 2) . "ms\n";
            echo "     - HTTP状态: {$responseData['http_code']}\n";
            
            if ($responseData['http_code'] === 200) {
                echo "     - Ping测试: ✅ 成功\n";
                $this->testResults['ping_request'] = true;
            } else {
                echo "     - Ping测试: ❌ 失败\n";
                $this->testResults['ping_request'] = false;
            }
            
        } catch (Exception $e) {
            echo "     - Ping异常: ❌ " . $e->getMessage() . "\n";
            $this->testResults['ping_request'] = false;
        }
    }
    
    /**
     * 5. 性能测试
     */
    private function runPerformanceTests() {
        echo "⚡ 性能压力测试\n";
        echo str_repeat("-", 50) . "\n";
        
        // 响应时间测试
        $this->testResponseTime();
        
        // 并发请求测试
        $this->testConcurrentRequests();
        
        echo "\n";
    }
    
    private function testResponseTime() {
        echo "  ⏱️ 响应时间性能测试...\n";
        
        $iterations = 10;
        $times = [];
        $request = $this->buildOfficialRequest('ANDROID');
        
        for ($i = 0; $i < $iterations; $i++) {
            try {
                $startTime = microtime(true);
                $response = $this->makeHttpRequest(
                    $this->baseUrl,
                    'POST',
                    $request['binary'],
                    $this->httpHeaders
                );
                $endTime = microtime(true);
                
                if ($response['http_code'] === 200) {
                    $times[] = ($endTime - $startTime) * 1000;
                }
                
                usleep(100000); // 100ms间隔
                
            } catch (Exception $e) {
                // 忽略错误，继续测试
            }
        }
        
        if (!empty($times)) {
            $avgTime = array_sum($times) / count($times);
            $maxTime = max($times);
            $minTime = min($times);
            
            echo "  📊 响应时间统计 ({$iterations}次测试):\n";
            echo "     - 平均时间: " . round($avgTime, 2) . "ms\n";
            echo "     - 最快时间: " . round($minTime, 2) . "ms\n";
            echo "     - 最慢时间: " . round($maxTime, 2) . "ms\n";
            
            if ($avgTime <= 100) {
                echo "  ✅ 性能评级: 优秀 (< 100ms)\n";
                $this->testResults['response_time'] = 'excellent';
            } elseif ($avgTime <= 200) {
                echo "  ✅ 性能评级: 良好 (< 200ms)\n";
                $this->testResults['response_time'] = 'good';
            } elseif ($avgTime <= 500) {
                echo "  ⚠️ 性能评级: 可接受 (< 500ms)\n";
                $this->testResults['response_time'] = 'acceptable';
            } else {
                echo "  ❌ 性能评级: 较慢 (>= 500ms)\n";
                $this->testResults['response_time'] = 'slow';
            }
        } else {
            echo "  ❌ 响应时间测试失败\n";
            $this->testResults['response_time'] = 'failed';
        }
    }
    
    private function testConcurrentRequests() {
        echo "  🔄 并发请求测试...\n";
        
        $concurrency = 5;
        $results = [];
        $request = $this->buildOfficialRequest('ANDROID');
        
        echo "     - 并发数量: {$concurrency}\n";
        
        $startTime = microtime(true);
        
        // 模拟并发请求
        for ($i = 0; $i < $concurrency; $i++) {
            try {
                $response = $this->makeHttpRequest(
                    $this->baseUrl,
                    'POST',
                    $request['binary'],
                    $this->httpHeaders
                );
                $results[] = ['success' => $response['http_code'] === 200];
            } catch (Exception $e) {
                $results[] = ['success' => false];
            }
        }
        
        $endTime = microtime(true);
        $totalTime = ($endTime - $startTime) * 1000;
        
        $successCount = count(array_filter($results, function($r) { return $r['success']; }));
        $successRate = round($successCount / $concurrency * 100, 1);
        
        echo "     - 成功请求: {$successCount}/{$concurrency}\n";
        echo "     - 成功率: {$successRate}%\n";
        echo "     - 总耗时: " . round($totalTime, 2) . "ms\n";
        echo "     - 平均耗时: " . round($totalTime / $concurrency, 2) . "ms\n";
        
        if ($successRate >= 90) {
            echo "  ✅ 并发测试: 优秀\n";
            $this->testResults['concurrent_requests'] = 'excellent';
        } elseif ($successRate >= 80) {
            echo "  ✅ 并发测试: 良好\n";
            $this->testResults['concurrent_requests'] = 'good';
        } else {
            echo "  ⚠️ 并发测试: 需要优化\n";
            $this->testResults['concurrent_requests'] = 'needs_improvement';
        }
    }
    
    /**
     * 6. 边界测试
     */
    private function runBoundaryTests() {
        echo "🧪 边界条件测试\n";
        echo str_repeat("-", 50) . "\n";
        
        // 空数据测试
        $this->testEmptyData();
        
        // 无效数据测试
        $this->testInvalidData();
        
        // 大数据量测试
        $this->testLargeData();
        
        echo "\n";
    }
    
    private function testEmptyData() {
        echo "  📭 空数据处理测试...\n";
        
        try {
            $response = $this->makeHttpRequest($this->baseUrl, 'POST', '', $this->httpHeaders);
            echo "     - HTTP状态: {$response['http_code']}\n";
            echo "     - 响应长度: " . strlen($response['body']) . " bytes\n";
            
            // 空数据应该返回错误，但不应该崩溃
            if ($response['http_code'] >= 200 && $response['http_code'] < 500) {
                echo "  ✅ 空数据处理正常\n";
                $this->testResults['empty_data'] = true;
            } else {
                echo "  ❌ 空数据处理异常\n";
                $this->testResults['empty_data'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 空数据测试异常: " . $e->getMessage() . "\n";
            $this->testResults['empty_data'] = false;
        }
    }
    
    private function testInvalidData() {
        echo "  🗑️ 无效数据处理测试...\n";
        
        try {
            $invalidData = str_repeat("\xFF\x00\xAA\x55", 100);
            $response = $this->makeHttpRequest($this->baseUrl, 'POST', $invalidData, $this->httpHeaders);
            
            echo "     - HTTP状态: {$response['http_code']}\n";
            echo "     - 响应长度: " . strlen($response['body']) . " bytes\n";
            
            if ($response['http_code'] >= 200 && $response['http_code'] < 500) {
                echo "  ✅ 无效数据处理正常\n";
                $this->testResults['invalid_data'] = true;
            } else {
                echo "  ❌ 无效数据处理异常\n";
                $this->testResults['invalid_data'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 无效数据测试异常: " . $e->getMessage() . "\n";
            $this->testResults['invalid_data'] = false;
        }
    }
    
    private function testLargeData() {
        echo "  📦 大数据量处理测试...\n";
        
        try {
            // 构建包含大量设备ID的请求
            $request = $this->buildLargeDataRequest();
            
            echo "     - 数据大小: " . strlen($request['binary']) . " bytes\n";
            
            $response = $this->makeHttpRequest($this->baseUrl, 'POST', $request['binary'], $this->httpHeaders);
            
            echo "     - HTTP状态: {$response['http_code']}\n";
            echo "     - 响应长度: " . strlen($response['body']) . " bytes\n";
            
            if ($response['http_code'] === 200) {
                echo "  ✅ 大数据量处理正常\n";
                $this->testResults['large_data'] = true;
            } else {
                echo "  ⚠️ 大数据量处理可能有限制\n";
                $this->testResults['large_data'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 大数据量测试异常: " . $e->getMessage() . "\n";
            $this->testResults['large_data'] = false;
        }
    }
    
    /**
     * 构建官方规范的RTA请求
     */
    private function buildOfficialRequest($osType) {
        $request = [
            'user_id' => '2088802123844356',
            'req_id' => $this->generateUUID(),
            'request_time' => $this->getCurrentTimeMillis(),
            'is_ping' => false,
            'device_info' => $this->buildDeviceInfo($osType),
            'rta_req_info' => []
        ];
        
        $request['binary'] = $this->encodeRtaRequest($request);
        return $request;
    }
    
    private function buildPingRequest() {
        $request = [
            'user_id' => '2088802123844356',
            'req_id' => $this->generateUUID(),
            'request_time' => $this->getCurrentTimeMillis(),
            'is_ping' => true,
            'device_info' => $this->buildDeviceInfo('ANDROID'),
            'rta_req_info' => []
        ];
        
        $request['binary'] = $this->encodeRtaRequest($request);
        return $request;
    }
    
    private function buildLargeDataRequest() {
        $deviceIds = [];
        
        // 生成大量设备ID
        for ($i = 0; $i < 20; $i++) {
            $deviceIds[] = [
                'type' => 'OAID_HASH',
                'value' => 'large_test_oaid_hash_' . $i . '_' . str_repeat('x', 50),
                'version' => ''
            ];
        }
        
        $request = [
            'user_id' => '2088802123844356',
            'req_id' => $this->generateUUID(),
            'request_time' => $this->getCurrentTimeMillis(),
            'is_ping' => false,
            'device_info' => [
                'os_type' => 'ANDROID',
                'device_ids' => $deviceIds
            ],
            'rta_req_info' => []
        ];
        
        $request['binary'] = $this->encodeRtaRequest($request);
        return $request;
    }
    
    /**
     * 构建设备信息
     */
    private function buildDeviceInfo($osType) {
        $deviceInfo = [
            'os_type' => $osType,
            'device_ids' => []
        ];
        
        if ($osType === 'IOS') {
            $deviceInfo['device_ids'] = [
                [
                    'type' => 'IDFA_HASH',
                    'value' => $this->md5Hash('739372CF-EA98-431F-AE1F-424BF1283444'),
                    'version' => ''
                ],
                [
                    'type' => 'CAID',
                    'value' => '869120047154725',
                    'version' => '20220111'
                ],
                [
                    'type' => 'CAID',
                    'value' => '869120047154725',
                    'version' => '20230330'
                ]
            ];
        } elseif ($osType === 'ANDROID') {
            $deviceInfo['device_ids'] = [
                [
                    'type' => 'OAID_HASH',
                    'value' => 'oaid_hash_to_bid_1',
                    'version' => ''
                ]
            ];
        }
        
        return $deviceInfo;
    }
    
    /**
     * Protobuf编码方法
     */
    private function encodeRtaRequest($request) {
        $data = '';
        
        // Field 1: user_id (string)
        if (!empty($request['user_id'])) {
            $data .= $this->encodeField(1, 2, $request['user_id']);
        }
        
        // Field 3: req_id (string)
        if (!empty($request['req_id'])) {
            $data .= $this->encodeField(3, 2, $request['req_id']);
        }
        
        // Field 7: request_time (int64)
        if (!empty($request['request_time'])) {
            $data .= $this->encodeField(7, 0, $request['request_time']);
        }
        
        // Field 8: is_ping (bool)
        $data .= $this->encodeField(8, 0, $request['is_ping'] ? 1 : 0);
        
        // Field 6: device_info (message)
        if (!empty($request['device_info'])) {
            $deviceInfoData = $this->encodeDeviceInfo($request['device_info']);
            $data .= $this->encodeField(6, 2, $deviceInfoData);
        }
        
        return $data;
    }
    
    private function encodeDeviceInfo($deviceInfo) {
        $data = '';
        
        // Field 1: os_type (enum)
        $osTypeValue = $this->getOsTypeValue($deviceInfo['os_type']);
        $data .= $this->encodeField(1, 0, $osTypeValue);
        
        // Field 4: device_id (repeated message)
        if (!empty($deviceInfo['device_ids'])) {
            foreach ($deviceInfo['device_ids'] as $deviceId) {
                $deviceIdData = $this->encodeDeviceId($deviceId);
                $data .= $this->encodeField(4, 2, $deviceIdData);
            }
        }
        
        return $data;
    }
    
    private function encodeDeviceId($deviceId) {
        $data = '';
        
        // Field 1: type (enum)
        $typeValue = $this->getIdTypeValue($deviceId['type']);
        $data .= $this->encodeField(1, 0, $typeValue);
        
        // Field 2: value (string)
        if (!empty($deviceId['value'])) {
            $data .= $this->encodeField(2, 2, $deviceId['value']);
        }
        
        // Field 3: version (string)
        if (!empty($deviceId['version'])) {
            $data .= $this->encodeField(3, 2, $deviceId['version']);
        }
        
        return $data;
    }
    
    private function encodeField($fieldNumber, $wireType, $value) {
        $tag = ($fieldNumber << 3) | $wireType;
        $result = $this->encodeVarint($tag);
        
        if ($wireType == 0) { // varint
            $result .= $this->encodeVarint($value);
        } elseif ($wireType == 2) { // length-delimited
            if (is_string($value)) {
                $result .= $this->encodeVarint(strlen($value));
                $result .= $value;
            } else {
                $result .= $this->encodeVarint(strlen($value));
                $result .= $value;
            }
        }
        
        return $result;
    }
    
    private function encodeVarint($value) {
        $result = '';
        while ($value >= 0x80) {
            $result .= chr(($value & 0x7F) | 0x80);
            $value >>= 7;
        }
        $result .= chr($value & 0x7F);
        return $result;
    }
    
    private function getOsTypeValue($osType) {
        $osTypes = ['UNKNOWN' => 0, 'IOS' => 1, 'ANDROID' => 2];
        return $osTypes[$osType] ?? 0;
    }
    
    private function getIdTypeValue($idType) {
        $idTypes = ['IDFA_HASH' => 0, 'OAID_HASH' => 1, 'CAID' => 2];
        return $idTypes[$idType] ?? 0;
    }
    
    /**
     * HTTP请求方法
     */
    private function makeHttpRequest($url, $method = 'GET', $data = null, $headers = []) {
        $ch = curl_init();
        
        $defaultHeaders = [
            'User-Agent: VivemallRtaTest-PHP/1.1.0',
            'Accept: */*',
            'Connection: close'
        ];
        
        $allHeaders = array_merge($defaultHeaders, $headers);
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT_MS => $this->timeout,
            CURLOPT_CONNECTTIMEOUT_MS => 5000,
            CURLOPT_HTTPHEADER => $allHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HEADER => false,
            CURLOPT_VERBOSE => false
        ]);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
        }
        
        $startTime = microtime(true);
        $response = curl_exec($ch);
        $endTime = microtime(true);
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $totalTime = ($endTime - $startTime) * 1000;
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception("HTTP请求错误: " . $error);
        }
        
        return [
            'http_code' => $httpCode,
            'body' => $response,
            'total_time' => round($totalTime, 2),
            'error' => $error
        ];
    }
    
    /**
     * 辅助方法
     */
    private function parseRtaResponse($data) {
        if (empty($data)) {
            return null;
        }
        
        // 简单的响应解析
        try {
            return [
                'raw_data' => bin2hex(substr($data, 0, 100)),
                'length' => strlen($data),
                'first_byte' => sprintf('%02X', ord($data[0])),
                'last_byte' => sprintf('%02X', ord($data[strlen($data)-1]))
            ];
        } catch (Exception $e) {
            return null;
        }
    }
    
    private function printResponseSummary($response) {
        if ($response) {
            echo "       响应长度: {$response['length']} bytes\n";
            echo "       首字节: 0x{$response['first_byte']}\n";
            echo "       末字节: 0x{$response['last_byte']}\n";
        }
    }
    
    private function md5Hash($input) {
        return strtolower(md5(strtoupper($input)));
    }
    
    private function generateUUID() {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    private function getCurrentTimeMillis() {
        return round(microtime(true) * 1000);
    }
    
    /**
     * 7. 生成完整测试报告
     */
    private function generateCompleteReport() {
        $totalTime = (microtime(true) - $this->startTime) * 1000;
        
        echo str_repeat("=", 80) . "\n";
        echo "📊 Vivemall RTA 服务完整测试报告\n";
        echo str_repeat("=", 80) . "\n";
        echo "🎯 测试目标: {$this->baseUrl}\n";
        echo "⏰ 测试耗时: " . round($totalTime, 2) . "ms\n";
        echo "📅 报告时间: " . date('Y-m-d H:i:s T') . "\n";
        echo "👤 执行用户: 100fun\n\n";
        
        // 分类统计
        $categories = [
            '环境检查' => ['php_version', 'curl_extension', 'json_extension', 'openssl_extension'],
            '网络连通' => ['dns_resolution', 'https_connection'],
            '基础功能' => ['health_check', 'basic_post'],
            '官方规范' => ['rta_request_ANDROID', 'rta_request_IOS', 'ping_request'],
            '性能测试' => ['response_time', 'concurrent_requests'],
            '边界测试' => ['empty_data', 'invalid_data', 'large_data']
        ];
        
        $overallPassed = 0;
        $overallTotal = 0;
        
        foreach ($categories as $categoryName => $tests) {
            $categoryPassed = 0;
            $categoryTotal = count($tests);
            
            echo "📋 {$categoryName}:\n";
            
            foreach ($tests as $test) {
                if (isset($this->testResults[$test])) {
                    $result = $this->testResults[$test];
                    
                    if (is_bool($result)) {
                        $status = $result ? "✅ 通过" : "❌ 失败";
                        if ($result) $categoryPassed++;
                    } else {
                        $status = "📊 " . $this->getGradeDescription($result);
                        if (in_array($result, ['excellent', 'good', 'acceptable'])) {
                            $categoryPassed++;
                        }
                    }
                    
                    echo "   {$test}: {$status}\n";
                    $overallTotal++;
                    if ($result === true || in_array($result, ['excellent', 'good', 'acceptable'])) {
                        $overallPassed++;
                    }
                }
            }
            
            $categoryRate = $categoryTotal > 0 ? round($categoryPassed / $categoryTotal * 100, 1) : 0;
            echo "   分类通过率: {$categoryPassed}/{$categoryTotal} ({$categoryRate}%)\n\n";
        }
        
        // 总体评估
        $overallRate = $overallTotal > 0 ? round($overallPassed / $overallTotal * 100, 1) : 0;
        
        echo "📈 总体统计:\n";
        echo "   总测试项: {$overallTotal}\n";
        echo "   通过项数: {$overallPassed}\n";
        echo "   总通过率: {$overallRate}%\n\n";
        
        // 最终评估
        echo "🎯 最终评估:\n";
        if ($overallRate >= 95) {
            echo "🏆 评估结果: 优秀\n";
            echo "✨ Vivemall RTA服务表现优秀，完全符合支付宝官方规范\n";
            echo "🚀 建议: 可以正式对接支付宝推广平台\n";
        } elseif ($overallRate >= 85) {
            echo "🥇 评估结果: 良好\n";
            echo "👍 Vivemall RTA服务表现良好，少数项目需要优化\n";
            echo "📝 建议: 优化失败项目后可以对接\n";
        } elseif ($overallRate >= 70) {
            echo "🥈 评估结果: 一般\n";
            echo "⚠️ Vivemall RTA服务基本可用，建议重点优化\n";
            echo "🔧 建议: 重点修复失败项目\n";
        } else {
            echo "🥉 评估结果: 需要改进\n";
            echo "❌ Vivemall RTA服务需要重大改进\n";
            echo "🛠️ 建议: 全面检查服务实现\n";
        }
        
        echo "\n📞 技术支持:\n";
        echo "- GitHub: https://github.com/100fun/AIimageSong/tree/master/ad-rta-test\n";
        echo "- 支付宝文档: https://adpub.alipay.com/lark/adrlark/by8otg013y0pc1o0\n";
        echo "- 执行时间: " . date('Y-m-d H:i:s T') . "\n";
        
        echo "\n" . str_repeat("=", 80) . "\n";
        echo "感谢使用 Vivemall RTA 自测工具！\n";
        echo str_repeat("=", 80) . "\n";
    }
    
    private function getGradeDescription($grade) {
        $grades = [
            'excellent' => '优秀 ⭐⭐⭐',
            'good' => '良好 ⭐⭐',
            'acceptable' => '可接受 ⭐',
            'needs_improvement' => '需要改进',
            'slow' => '较慢',
            'failed' => '失败'
        ];
        
        return $grades[$grade] ?? $grade;
    }
}

// ========================================
// 执行入口
// ========================================

if (php_sapi_name() === 'cli') {
    // 命令行执行
    echo "🚀 启动 Vivemall RTA 服务自测工具\n";
    echo "目标URL: https://ads.vivemall.com/alirta/rta_proxy.php\n";
    echo "执行时间: " . date('Y-m-d H:i:s T') . "\n";
    echo "执行用户: 100fun\n\n";
    
    $tester = new VivemallRtaTest();
    $tester->runCompleteTest();
    
} else {
    // Web执行
    header('Content-Type: text/plain; charset=utf-8');
    
    echo "🌐 Web模式执行 Vivemall RTA 自测\n\n";
    
    $tester = new VivemallRtaTest();
    $tester->runCompleteTest();
}

?>