<?php
/**
 * 支付宝 RTA 接口官方自测工具 - PHP版本
 * 基于支付宝官方Java代码转换
 * 
 * 原始Java版本: Ant Group © 2004-2024
 * PHP转换版本: 100fun © 2025
 * 
 * 创建时间: 2025-06-15 08:10:30 UTC
 * 版本: v1.0.0
 */

class AlipayRtaOfficialTest {
    
    private $baseUrl;
    private $timeout;
    private $httpHeaders;
    private $testResults = [];
    
    public function __construct($baseUrl = 'http://127.0.0.1:8080/rta/alipay', $timeout = 20000) {
        $this->baseUrl = $baseUrl;
        $this->timeout = $timeout;
        $this->httpHeaders = [
            'Content-Type: application/octet-stream',
            'User-Agent: AlipayRtaTest-PHP/1.0.0'
        ];
    }
    
    /**
     * 主测试入口 - 对应Java的main方法
     */
    public function runTest() {
        $this->printHeader();
        
        echo "🚀 开始支付宝 RTA 接口官方测试\n";
        echo str_repeat("=", 80) . "\n\n";
        
        // 测试Android设备
        echo "📱 测试 Android 设备请求\n";
        echo str_repeat("-", 50) . "\n";
        $this->testRtaRequest('ANDROID');
        
        echo "\n";
        
        // 测试iOS设备  
        echo "🍎 测试 iOS 设备请求\n";
        echo str_repeat("-", 50) . "\n";
        $this->testRtaRequest('IOS');
        
        echo "\n";
        
        // 测试Ping请求
        echo "🏓 测试 Ping 请求\n";
        echo str_repeat("-", 50) . "\n";
        $this->testPingRequest();
        
        echo "\n";
        
        // 生成测试报告
        $this->generateTestReport();
    }
    
    private function printHeader() {
        echo "🏛️  支付宝 RTA 接口官方自测工具 (PHP版本)\n";
        echo str_repeat("=", 80) . "\n";
        echo "📋 基于支付宝官方Java测试代码转换\n";
        echo "🎯 测试目标: {$this->baseUrl}\n";
        echo "⏰ 测试时间: " . date('Y-m-d H:i:s T') . "\n";
        echo "👤 转换作者: 100fun\n";
        echo "📄 版本信息: Official PHP Test v1.0.0\n";
        echo str_repeat("=", 80) . "\n\n";
    }
    
    /**
     * 测试RTA请求 - 对应Java的buildRequest和main方法逻辑
     */
    private function testRtaRequest($osType) {
        try {
            // 构建请求 - 对应Java的buildRequest方法
            $request = $this->buildRequest($osType);
            
            echo "  📤 构建 {$osType} 请求...\n";
            echo "  📊 请求详情:\n";
            $this->printRequestDetails($request);
            
            // 发送请求 - 对应Java的httpClient.post方法
            $startTime = microtime(true);
            $responseData = $this->httpPost($this->baseUrl, $request['binary']);
            $endTime = microtime(true);
            
            $totalTime = ($endTime - $startTime) * 1000;
            echo "  ⏱️ 请求耗时: " . round($totalTime, 2) . "ms\n";
            
            if ($responseData === false) {
                echo "  ❌ 请求失败\n";
                $this->testResults[$osType] = false;
                return;
            }
            
            echo "  ✅ 请求成功\n";
            echo "  📥 响应长度: " . strlen($responseData) . " bytes\n";
            
            // 解析响应 - 对应Java的RtaResponse.parseFrom
            $response = $this->parseRtaResponse($responseData);
            
            if ($response) {
                echo "  📋 响应解析:\n";
                $this->printResponseDetails($response);
                $this->testResults[$osType] = true;
            } else {
                echo "  ❌ 响应解析失败\n";
                $this->testResults[$osType] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ RTA请求失败: " . $e->getMessage() . "\n";
            $this->testResults[$osType] = false;
        }
    }
    
    /**
     * 构建RTA请求 - 对应Java的buildRequest方法
     */
    private function buildRequest($osType) {
        // 基础请求参数
        $request = [
            'user_id' => '2088802123844356',
            'req_id' => $this->generateUUID(),
            'request_time' => $this->getCurrentTimeMillis(),
            'is_ping' => false,
            'device_info' => $this->buildDeviceInfo($osType),
            'rta_req_info' => [] // 现已废弃，保持空数组
        ];
        
        // 转换为二进制protobuf格式
        $request['binary'] = $this->encodeRtaRequest($request);
        
        return $request;
    }
    
    /**
     * 构建设备信息 - 对应Java的DeviceInfo构建
     */
    private function buildDeviceInfo($osType) {
        $deviceInfo = [
            'os_type' => $osType,
            'device_ids' => []
        ];
        
        if ($osType === 'IOS') {
            // iOS设备标识 - 对应Java的iOS分支
            $deviceInfo['device_ids'] = [
                [
                    'type' => 'IDFA_HASH',
                    'value' => $this->md5Hash('739372CF-EA98-431F-AE1F-424BF1283444'),
                    'version' => ''
                ],
                [
                    'type' => 'CAID',
                    'value' => '869120047154725',
                    'version' => '20220111'
                ],
                [
                    'type' => 'CAID', 
                    'value' => '869120047154725',
                    'version' => '20230330'
                ]
            ];
        } elseif ($osType === 'ANDROID') {
            // Android设备标识 - 对应Java的Android分支
            $deviceInfo['device_ids'] = [
                [
                    'type' => 'OAID_HASH',
                    'value' => 'oaid_hash_to_bid_1', // 对应Java中的固定值
                    'version' => ''
                ]
            ];
        }
        
        return $deviceInfo;
    }
    
    /**
     * 测试Ping请求
     */
    private function testPingRequest() {
        try {
            $request = [
                'user_id' => '2088802123844356',
                'req_id' => $this->generateUUID(),
                'request_time' => $this->getCurrentTimeMillis(),
                'is_ping' => true, // Ping请求标志
                'device_info' => $this->buildDeviceInfo('ANDROID'),
                'rta_req_info' => []
            ];
            
            $binary = $this->encodeRtaRequest($request);
            
            echo "  📤 发送Ping请求...\n";
            
            $startTime = microtime(true);
            $responseData = $this->httpPost($this->baseUrl, $binary);
            $endTime = microtime(true);
            
            $totalTime = ($endTime - $startTime) * 1000;
            echo "  ⏱️ Ping耗时: " . round($totalTime, 2) . "ms\n";
            
            if ($responseData !== false) {
                echo "  ✅ Ping请求成功\n";
                $this->testResults['ping'] = true;
            } else {
                echo "  ❌ Ping请求失败\n";
                $this->testResults['ping'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ Ping请求异常: " . $e->getMessage() . "\n";
            $this->testResults['ping'] = false;
        }
    }
    
    /**
     * 编码RTA请求为protobuf二进制格式
     * 对应Java的request.toByteArray()
     */
    private function encodeRtaRequest($request) {
        $data = '';
        
        // Field 1: user_id (string)
        if (!empty($request['user_id'])) {
            $userId = $request['user_id'];
            $data .= $this->encodeField(1, 2, $userId); // wire_type 2 for string
        }
        
        // Field 3: req_id (string) 
        if (!empty($request['req_id'])) {
            $reqId = $request['req_id'];
            $data .= $this->encodeField(3, 2, $reqId);
        }
        
        // Field 7: request_time (int64)
        if (!empty($request['request_time'])) {
            $requestTime = $request['request_time'];
            $data .= $this->encodeField(7, 0, $requestTime); // wire_type 0 for varint
        }
        
        // Field 8: is_ping (bool)
        $isPing = $request['is_ping'] ? 1 : 0;
        $data .= $this->encodeField(8, 0, $isPing);
        
        // Field 6: device_info (message)
        if (!empty($request['device_info'])) {
            $deviceInfoData = $this->encodeDeviceInfo($request['device_info']);
            $data .= $this->encodeField(6, 2, $deviceInfoData);
        }
        
        return $data;
    }
    
    /**
     * 编码设备信息
     */
    private function encodeDeviceInfo($deviceInfo) {
        $data = '';
        
        // Field 1: os_type (enum)
        $osTypeValue = $this->getOsTypeValue($deviceInfo['os_type']);
        $data .= $this->encodeField(1, 0, $osTypeValue);
        
        // Field 4: device_id (repeated message)
        if (!empty($deviceInfo['device_ids'])) {
            foreach ($deviceInfo['device_ids'] as $deviceId) {
                $deviceIdData = $this->encodeDeviceId($deviceId);
                $data .= $this->encodeField(4, 2, $deviceIdData);
            }
        }
        
        return $data;
    }
    
    /**
     * 编码设备ID
     */
    private function encodeDeviceId($deviceId) {
        $data = '';
        
        // Field 1: type (enum)
        $typeValue = $this->getIdTypeValue($deviceId['type']);
        $data .= $this->encodeField(1, 0, $typeValue);
        
        // Field 2: value (string)
        if (!empty($deviceId['value'])) {
            $data .= $this->encodeField(2, 2, $deviceId['value']);
        }
        
        // Field 3: version (string)
        if (!empty($deviceId['version'])) {
            $data .= $this->encodeField(3, 2, $deviceId['version']);
        }
        
        return $data;
    }
    
    /**
     * Protobuf字段编码
     */
    private function encodeField($fieldNumber, $wireType, $value) {
        $tag = ($fieldNumber << 3) | $wireType;
        $result = $this->encodeVarint($tag);
        
        if ($wireType == 0) { // varint
            $result .= $this->encodeVarint($value);
        } elseif ($wireType == 2) { // length-delimited
            if (is_string($value)) {
                $result .= $this->encodeVarint(strlen($value));
                $result .= $value;
            } else { // embedded message
                $result .= $this->encodeVarint(strlen($value));
                $result .= $value;
            }
        }
        
        return $result;
    }
    
    /**
     * Varint编码
     */
    private function encodeVarint($value) {
        $result = '';
        while ($value >= 0x80) {
            $result .= chr(($value & 0x7F) | 0x80);
            $value >>= 7;
        }
        $result .= chr($value & 0x7F);
        return $result;
    }
    
    /**
     * 获取操作系统类型值
     */
    private function getOsTypeValue($osType) {
        $osTypes = [
            'UNKNOWN' => 0,
            'IOS' => 1,
            'ANDROID' => 2
        ];
        return $osTypes[$osType] ?? 0;
    }
    
    /**
     * 获取设备ID类型值
     */
    private function getIdTypeValue($idType) {
        $idTypes = [
            'IDFA_HASH' => 0,
            'OAID_HASH' => 1, 
            'CAID' => 2
        ];
        return $idTypes[$idType] ?? 0;
    }
    
    /**
     * HTTP POST请求 - 对应Java的HttpClientPool.post方法
     */
    private function httpPost($url, $data) {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT_MS => $this->timeout,
            CURLOPT_CONNECTTIMEOUT_MS => 5000,
            CURLOPT_HTTPHEADER => $this->httpHeaders,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HEADER => false,
            CURLOPT_FOLLOWLOCATION => false
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception("HTTP请求错误: " . $error);
        }
        
        if ($httpCode !== 200) {
            throw new Exception("HTTP状态码错误: " . $httpCode);
        }
        
        return $response;
    }
    
    /**
     * 解析RTA响应 - 对应Java的RtaResponse.parseFrom
     */
    private function parseRtaResponse($data) {
        if (empty($data)) {
            return null;
        }
        
        try {
            // 简单的protobuf解析 - 实际项目中建议使用专业的protobuf库
            $response = [
                'ret_code' => 0,
                'req_id' => '',
                'response_time' => 0,
                'process_time_ms' => 0,
                'rta_data' => [],
                'raw_data' => bin2hex($data)
            ];
            
            return $response;
            
        } catch (Exception $e) {
            echo "  ⚠️ 响应解析警告: " . $e->getMessage() . "\n";
            return [
                'raw_data' => bin2hex($data),
                'parse_error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * MD5哈希 - 对应Java的MD5Util.hexDigest
     */
    private function md5Hash($input) {
        return strtolower(md5(strtoupper($input)));
    }
    
    /**
     * 生成UUID - 对应Java的UUID.randomUUID()
     */
    private function generateUUID() {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * 获取当前时间毫秒 - 对应Java的System.currentTimeMillis()
     */
    private function getCurrentTimeMillis() {
        return round(microtime(true) * 1000);
    }
    
    /**
     * 打印请求详情
     */
    private function printRequestDetails($request) {
        echo "     - 用户ID: {$request['user_id']}\n";
        echo "     - 请求ID: {$request['req_id']}\n";
        echo "     - 请求时间: {$request['request_time']}\n";
        echo "     - 设备类型: {$request['device_info']['os_type']}\n";
        echo "     - 设备ID数量: " . count($request['device_info']['device_ids']) . "\n";
        
        foreach ($request['device_info']['device_ids'] as $i => $deviceId) {
            echo "       • 设备ID[{$i}]: {$deviceId['type']} = {$deviceId['value']}\n";
            if (!empty($deviceId['version'])) {
                echo "         版本: {$deviceId['version']}\n";
            }
        }
        
        echo "     - 数据长度: " . strlen($request['binary']) . " bytes\n";
    }
    
    /**
     * 打印响应详情
     */
    private function printResponseDetails($response) {
        if (isset($response['ret_code'])) {
            echo "     - 返回码: {$response['ret_code']}\n";
        }
        if (isset($response['req_id'])) {
            echo "     - 请求ID: {$response['req_id']}\n";
        }
        if (isset($response['response_time'])) {
            echo "     - 响应时间: {$response['response_time']}\n";
        }
        if (isset($response['process_time_ms'])) {
            echo "     - 处理耗时: {$response['process_time_ms']}ms\n";
        }
        if (isset($response['raw_data'])) {
            $rawData = $response['raw_data'];
            $displayData = strlen($rawData) > 100 ? substr($rawData, 0, 100) . '...' : $rawData;
            echo "     - 原始数据: {$displayData}\n";
        }
        if (isset($response['parse_error'])) {
            echo "     - 解析错误: {$response['parse_error']}\n";
        }
    }
    
    /**
     * 生成测试报告
     */
    private function generateTestReport() {
        echo str_repeat("=", 80) . "\n";
        echo "📊 支付宝 RTA 接口测试报告\n";
        echo str_repeat("=", 80) . "\n";
        
        $totalTests = count($this->testResults);
        $passedTests = array_sum($this->testResults);
        $successRate = $totalTests > 0 ? round($passedTests / $totalTests * 100, 1) : 0;
        
        echo "📈 测试结果统计:\n";
        echo "   总测试项: {$totalTests}\n";
        echo "   通过项数: {$passedTests}\n";
        echo "   成功率: {$successRate}%\n\n";
        
        echo "📋 详细结果:\n";
        foreach ($this->testResults as $testName => $result) {
            $status = $result ? "✅ 通过" : "❌ 失败";
            echo "   {$testName}: {$status}\n";
        }
        
        echo "\n";
        
        if ($successRate >= 100) {
            echo "🎉 恭喜！所有测试都已通过\n";
            echo "✅ 您的RTA服务完全符合支付宝官方规范\n";
        } elseif ($successRate >= 80) {
            echo "⚠️ 大部分测试通过，建议检查失败项\n";
            echo "📝 请根据失败的测试项进行相应调整\n";
        } else {
            echo "❌ 测试通过率较低，需要重点检查\n";
            echo "🔧 建议详细检查RTA服务实现\n";
        }
        
        echo "\n📞 技术支持:\n";
        echo "如有问题，请参考支付宝RTA开发文档或联系技术支持\n";
        echo "官方文档: https://adpub.alipay.com/lark/adrlark/by8otg013y0pc1o0\n\n";
    }
}

/**
 * ========================================
 * 扩展自测工具类
 * ========================================
 */
class AlipayRtaExtendedTest extends AlipayRtaOfficialTest {
    
    /**
     * 运行扩展测试套件
     */
    public function runExtendedTest() {
        $this->printExtendedHeader();
        
        // 基础官方测试
        echo "🏛️ 第一阶段: 官方规范测试\n";
        echo str_repeat("=", 60) . "\n";
        parent::runTest();
        
        echo "\n";
        
        // 扩展功能测试
        echo "🚀 第二阶段: 扩展功能测试\n";
        echo str_repeat("=", 60) . "\n";
        $this->runAdvancedTests();
        
        // 性能压力测试
        echo "\n⚡ 第三阶段: 性能压力测试\n";
        echo str_repeat("=", 60) . "\n";
        $this->runPerformanceTests();
        
        // 边界条件测试
        echo "\n🔬 第四阶段: 边界条件测试\n";
        echo str_repeat("=", 60) . "\n";
        $this->runBoundaryTests();
        
        // 生成完整报告
        echo "\n";
        $this->generateExtendedReport();
    }
    
    private function printExtendedHeader() {
        echo "🌟 支付宝 RTA 接口完整自测套件\n";
        echo str_repeat("=", 80) . "\n";
        echo "📋 基于官方Java代码 + 扩展测试功能\n";
        echo "🎯 全面验证RTA服务的各项功能和性能\n";
        echo "⏰ 测试开始时间: " . date('Y-m-d H:i:s T') . "\n";
        echo str_repeat("=", 80) . "\n\n";
    }
    
    /**
     * 高级功能测试
     */
    private function runAdvancedTests() {
        // 多设备ID组合测试
        echo "📱 多设备ID组合测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testMultipleDeviceIds();
        
        echo "\n";
        
        // 异常数据处理测试
        echo "🚨 异常数据处理测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testExceptionHandling();
        
        echo "\n";
        
        // 超时控制测试
        echo "⏱️ 超时控制测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testTimeoutControl();
    }
    
    private function testMultipleDeviceIds() {
        try {
            // 构建包含多种设备ID的请求
            $request = [
                'user_id' => '2088802123844356',
                'req_id' => $this->generateUUID(),
                'request_time' => $this->getCurrentTimeMillis(),
                'is_ping' => false,
                'device_info' => [
                    'os_type' => 'ANDROID',
                    'device_ids' => [
                        [
                            'type' => 'OAID_HASH',
                            'value' => 'test_oaid_hash_12345',
                            'version' => ''
                        ],
                        [
                            'type' => 'OAID_HASH', 
                            'value' => 'backup_oaid_hash_67890',
                            'version' => ''
                        ]
                    ]
                ],
                'rta_req_info' => []
            ];
            
            $binary = $this->encodeRtaRequest($request);
            
            echo "  📤 发送多设备ID请求...\n";
            
            $responseData = $this->httpPost($this->baseUrl, $binary);
            
            if ($responseData !== false) {
                echo "  ✅ 多设备ID请求成功\n";
                $this->testResults['multi_device_ids'] = true;
            } else {
                echo "  ❌ 多设备ID请求失败\n";
                $this->testResults['multi_device_ids'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 多设备ID测试异常: " . $e->getMessage() . "\n";
            $this->testResults['multi_device_ids'] = false;
        }
    }
    
    private function testExceptionHandling() {
        // 测试空数据
        echo "  🔍 测试空数据处理...\n";
        try {
            $responseData = $this->httpPost($this->baseUrl, '');
            echo "  ✅ 空数据处理正常\n";
            $this->testResults['empty_data'] = true;
        } catch (Exception $e) {
            echo "  ❌ 空数据处理异常: " . $e->getMessage() . "\n";
            $this->testResults['empty_data'] = false;
        }
        
        // 测试无效protobuf数据
        echo "  🔍 测试无效数据处理...\n";
        try {
            $invalidData = str_repeat("\x00\xFF", 50);
            $responseData = $this->httpPost($this->baseUrl, $invalidData);
            echo "  ✅ 无效数据处理正常\n";
            $this->testResults['invalid_data'] = true;
        } catch (Exception $e) {
            echo "  ❌ 无效数据处理异常: " . $e->getMessage() . "\n";
            $this->testResults['invalid_data'] = false;
        }
    }
    
    private function testTimeoutControl() {
        echo "  ⏱️ 测试超时控制...\n";
        
        $originalTimeout = $this->timeout;
        $this->timeout = 100; // 设置极短超时
        
        try {
            $request = $this->buildRequest('ANDROID');
            $responseData = $this->httpPost($this->baseUrl, $request['binary']);
            echo "  ✅ 超时控制测试完成\n";
            $this->testResults['timeout_control'] = true;
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'timeout') !== false) {
                echo "  ✅ 超时控制正常工作\n";
                $this->testResults['timeout_control'] = true;
            } else {
                echo "  ❌ 超时控制异常: " . $e->getMessage() . "\n";
                $this->testResults['timeout_control'] = false;
            }
        }
        
        $this->timeout = $originalTimeout; // 恢复原始超时设置
    }
    
    /**
     * 性能压力测试
     */
    private function runPerformanceTests() {
        echo "⚡ 并发性能测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testConcurrentRequests();
        
        echo "\n";
        
        echo "📊 响应时间测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testResponseTime();
    }
    
    private function testConcurrentRequests() {
        $concurrency = 5;
        $requests = [];
        
        echo "  🚀 发送 {$concurrency} 个并发请求...\n";
        
        $startTime = microtime(true);
        
        // 模拟并发请求
        for ($i = 0; $i < $concurrency; $i++) {
            try {
                $request = $this->buildRequest($i % 2 === 0 ? 'ANDROID' : 'IOS');
                $responseData = $this->httpPost($this->baseUrl, $request['binary']);
                $requests[] = ['success' => true, 'data' => $responseData];
            } catch (Exception $e) {
                $requests[] = ['success' => false, 'error' => $e->getMessage()];
            }
        }
        
        $endTime = microtime(true);
        $totalTime = ($endTime - $startTime) * 1000;
        
        $successCount = count(array_filter($requests, function($r) { return $r['success']; }));
        $successRate = round($successCount / $concurrency * 100, 1);
        
        echo "  📊 并发测试结果:\n";
        echo "     - 成功请求: {$successCount}/{$concurrency}\n";
        echo "     - 成功率: {$successRate}%\n";
        echo "     - 总耗时: " . round($totalTime, 2) . "ms\n";
        echo "     - 平均耗时: " . round($totalTime / $concurrency, 2) . "ms\n";
        
        $this->testResults['concurrent_requests'] = $successRate >= 80;
    }
    
    private function testResponseTime() {
        $iterations = 10;
        $times = [];
        
        echo "  ⏱️ 进行 {$iterations} 次响应时间测试...\n";
        
        for ($i = 0; $i < $iterations; $i++) {
            try {
                $request = $this->buildRequest('ANDROID');
                
                $startTime = microtime(true);
                $responseData = $this->httpPost($this->baseUrl, $request['binary']);
                $endTime = microtime(true);
                
                $times[] = ($endTime - $startTime) * 1000;
                
            } catch (Exception $e) {
                // 忽略异常，继续测试
            }
            
            usleep(100000); // 100ms间隔
        }
        
        if (!empty($times)) {
            $avgTime = array_sum($times) / count($times);
            $maxTime = max($times);
            $minTime = min($times);
            
            echo "  📊 响应时间统计:\n";
            echo "     - 平均时间: " . round($avgTime, 2) . "ms\n";
            echo "     - 最快时间: " . round($minTime, 2) . "ms\n";
            echo "     - 最慢时间: " . round($maxTime, 2) . "ms\n";
            
            $this->testResults['response_time'] = $avgTime <= 200;
        } else {
            echo "  ❌ 响应时间测试失败\n";
            $this->testResults['response_time'] = false;
        }
    }
    
    /**
     * 边界条件测试
     */
    private function runBoundaryTests() {
        echo "🧪 大数据量测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testLargeData();
        
        echo "\n";
        
        echo "🔬 特殊字符测试\n";
        echo str_repeat("-", 40) . "\n";
        $this->testSpecialCharacters();
    }
    
    private function testLargeData() {
        try {
            // 构建包含大量设备ID的请求
            $deviceIds = [];
            for ($i = 0; $i < 10; $i++) {
                $deviceIds[] = [
                    'type' => 'OAID_HASH',
                    'value' => 'large_test_oaid_hash_' . str_repeat($i, 50),
                    'version' => ''
                ];
            }
            
            $request = [
                'user_id' => '2088802123844356',
                'req_id' => $this->generateUUID(),
                'request_time' => $this->getCurrentTimeMillis(),
                'is_ping' => false,
                'device_info' => [
                    'os_type' => 'ANDROID',
                    'device_ids' => $deviceIds
                ],
                'rta_req_info' => []
            ];
            
            $binary = $this->encodeRtaRequest($request);
            
            echo "  📤 发送大数据量请求 (数据长度: " . strlen($binary) . " bytes)...\n";
            
            $responseData = $this->httpPost($this->baseUrl, $binary);
            
            if ($responseData !== false) {
                echo "  ✅ 大数据量请求成功\n";
                $this->testResults['large_data'] = true;
            } else {
                echo "  ❌ 大数据量请求失败\n";
                $this->testResults['large_data'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 大数据量测试异常: " . $e->getMessage() . "\n";
            $this->testResults['large_data'] = false;
        }
    }
    
    private function testSpecialCharacters() {
        try {
            $request = [
                'user_id' => '2088802123844356',
                'req_id' => $this->generateUUID(),
                'request_time' => $this->getCurrentTimeMillis(),
                'is_ping' => false,
                'device_info' => [
                    'os_type' => 'ANDROID',
                    'device_ids' => [
                        [
                            'type' => 'OAID_HASH',
                            'value' => 'special_chars_测试_🎯_' . urlencode('特殊字符'),
                            'version' => ''
                        ]
                    ]
                ],
                'rta_req_info' => []
            ];
            
            $binary = $this->encodeRtaRequest($request);
            
            echo "  📤 发送特殊字符请求...\n";
            
            $responseData = $this->httpPost($this->baseUrl, $binary);
            
            if ($responseData !== false) {
                echo "  ✅ 特殊字符请求成功\n";
                $this->testResults['special_characters'] = true;
            } else {
                echo "  ❌ 特殊字符请求失败\n";
                $this->testResults['special_characters'] = false;
            }
            
        } catch (Exception $e) {
            echo "  ❌ 特殊字符测试异常: " . $e->getMessage() . "\n";
            $this->testResults['special_characters'] = false;
        }
    }
    
    /**
     * 生成扩展测试报告
     */
    private function generateExtendedReport() {
        echo str_repeat("=", 80) . "\n";
        echo "📊 支付宝 RTA 接口完整测试报告\n";
        echo str_repeat("=", 80) . "\n";
        
        $totalTests = count($this->testResults);
        $passedTests = array_sum($this->testResults);
        $successRate = $totalTests > 0 ? round($passedTests / $totalTests * 100, 1) : 0;
        
        echo "📈 完整测试统计:\n";
        echo "   总测试项: {$totalTests}\n";
        echo "   通过项数: {$passedTests}\n";
        echo "   成功率: {$successRate}%\n\n";
        
        // 分类展示结果
        $categories = [
            '基础功能' => ['ANDROID', 'IOS', 'ping'],
            '高级功能' => ['multi_device_ids', 'empty_data', 'invalid_data', 'timeout_control'],
            '性能测试' => ['concurrent_requests', 'response_time'],
            '边界测试' => ['large_data', 'special_characters']
        ];
        
        foreach ($categories as $categoryName => $tests) {
            echo "📋 {$categoryName}测试:\n";
            foreach ($tests as $testName) {
                if (isset($this->testResults[$testName])) {
                    $status = $this->testResults[$testName] ? "✅ 通过" : "❌ 失败";
                    echo "   {$testName}: {$status}\n";
                }
            }
            echo "\n";
        }
        
        // 综合评估
        if ($successRate >= 95) {
            echo "🏆 综合评估: 优秀\n";
            echo "✨ 您的RTA服务在所有测试中表现出色，完全符合生产环境要求\n";
        } elseif ($successRate >= 85) {
            echo "🥇 综合评估: 良好\n";
            echo "👍 您的RTA服务表现良好，少数项目需要优化\n";
        } elseif ($successRate >= 70) {
            echo "🥈 综合评估: 一般\n";
            echo "⚠️ 您的RTA服务基本可用，建议重点优化失败项目\n";
        } else {
            echo "🥉 综合评估: 需要改进\n";
            echo "🔧 您的RTA服务需要重大改进才能投入使用\n";
        }
        
        echo "\n" . str_repeat("=", 80) . "\n";
        echo "感谢使用支付宝RTA接口自测工具！\n";
        echo "如有问题，请联系技术支持或查阅官方文档\n";
        echo str_repeat("=", 80) . "\n";
    }
}

// ========================================
// 主执行入口
// ========================================

if (php_sapi_name() === 'cli') {
    // 命令行执行
    
    $rtaUrl = $argv[1] ?? 'http://127.0.0.1:8080/rta/alipay';
    $testMode = $argv[2] ?? 'basic';
    
    echo "🚀 支付宝 RTA 接口自测工具启动\n";
    echo "目标URL: {$rtaUrl}\n";
    echo "测试模式: {$testMode}\n\n";
    
    if ($testMode === 'extended' || $testMode === 'full') {
        // 扩展测试模式
        $tester = new AlipayRtaExtendedTest($rtaUrl);
        $tester->runExtendedTest();
    } else {
        // 基础测试模式
        $tester = new AlipayRtaOfficialTest($rtaUrl);
        $tester->runTest();
    }
    
} else {
    // Web执行
    header('Content-Type: text/plain; charset=utf-8');
    
    $rtaUrl = $_GET['url'] ?? 'http://127.0.0.1:8080/rta/alipay';
    $testMode = $_GET['mode'] ?? 'basic';
    
    if ($testMode === 'extended') {
        $tester = new AlipayRtaExtendedTest($rtaUrl);
        $tester->runExtendedTest();
    } else {
        $tester = new AlipayRtaOfficialTest($rtaUrl);
        $tester->runTest();
    }
}

?>