<?php
/**
 * 完整的 RTA 服务测试 - 使用修复后的 protobuf 类
 */

require_once __DIR__ . '/vendor/autoload.php';

use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaResponse;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaReqInfo;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_DeviceInfo;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_DeviceID;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_IDType;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_OsType;

/**
 * 创建支付宝示例请求
 */
function createAlipayRequest($testType = 'normal') {
    $rtaRequest = new RtaRequest();
    
    // 基于支付宝示例的字段
    $rtaRequest->setUserId('2088802123844356');
    $rtaRequest->setReqId('780dea69-7ea6-4829-a931-a6a44a1dd56a');
    $rtaRequest->setRequestTime(1727254823059);
    $rtaRequest->setOneId('one_id_' . uniqid());
    
    switch ($testType) {
        case 'ping':
            $rtaRequest->setIsPing(true);
            break;
            
        case 'normal':
            $rtaRequest->setIsPing(false);
            
            // 设置设备信息
            $deviceInfo = new RtaRequest_DeviceInfo();
            $deviceInfo->setOsType(RtaRequest_OsType::ANDROID);
            $deviceInfo->setAlipayClientVersion('10.3.20.8100');
            
            // 添加 OAID_HASH 设备ID
            $deviceId = new RtaRequest_DeviceID();
            $deviceId->setType(RtaRequest_IDType::OAID_HASH);
            $deviceId->setValue('oaid_hash_to_bid_1');
            $deviceInfo->getDeviceId()[] = $deviceId;
            
            $rtaRequest->setDeviceInfo($deviceInfo);
            
            // 添加 RTA 请求信息
            $rtaReqInfo1 = new RtaReqInfo();
            $rtaReqInfo1->setRtaId('rta_id_1');
            $rtaReqInfo1->setAdId('100492304');
            $rtaRequest->getRtaReqInfo()[] = $rtaReqInfo1;
            
            $rtaReqInfo2 = new RtaReqInfo();
            $rtaReqInfo2->setRtaId('rta_id_2');
            $rtaReqInfo2->setAdId('100492305');
            $rtaRequest->getRtaReqInfo()[] = $rtaReqInfo2;
            break;
            
        case 'no_rta_info':
            $rtaRequest->setIsPing(false);
            
            // 设备信息
            $deviceInfo = new RtaRequest_DeviceInfo();
            $deviceInfo->setOsType(RtaRequest_OsType::IOS);
            $deviceInfo->setAlipayClientVersion('10.3.20.8100');
            
            // 添加 IDFA_HASH 设备ID
            $deviceId = new RtaRequest_DeviceID();
            $deviceId->setType(RtaRequest_IDType::IDFA_HASH);
            $deviceId->setValue('46b4c4e7ee80c725b094ea093cdf3435');
            $deviceInfo->getDeviceId()[] = $deviceId;
            
            $rtaRequest->setDeviceInfo($deviceInfo);
            // 不添加 rta_req_info - 模拟新版本协议
            break;
            
        case 'caid':
            $rtaRequest->setIsPing(false);
            
            // 设备信息
            $deviceInfo = new RtaRequest_DeviceInfo();
            $deviceInfo->setOsType(RtaRequest_OsType::IOS);
            $deviceInfo->setAlipayClientVersion('10.3.20.8100');
            
            // 添加 CAID 设备ID
            $deviceId = new RtaRequest_DeviceID();
            $deviceId->setType(RtaRequest_IDType::CAID);
            $deviceId->setValue('9f9a3e19cac46b80c45cf34fd27bd529');
            $deviceId->setVersion('20230330');
            $deviceInfo->getDeviceId()[] = $deviceId;
            
            $rtaRequest->setDeviceInfo($deviceInfo);
            break;
    }
    
    return $rtaRequest;
}

/**
 * 发送并测试 RTA 请求
 */
function testRtaRequest($url, $rtaRequest, $testName) {
    echo "\n" . str_repeat("=", 70) . "\n";
    echo "测试: {$testName}\n";
    echo str_repeat("=", 70) . "\n";
    
    // 显示请求详情
    echo "请求详情:\n";
    echo "  用户ID: " . $rtaRequest->getUserId() . "\n";
    echo "  请求ID: " . $rtaRequest->getReqId() . "\n";
    echo "  请求时间: " . date('Y-m-d H:i:s', $rtaRequest->getRequestTime() / 1000) . "\n";
    echo "  是否Ping: " . ($rtaRequest->getIsPing() ? 'true' : 'false') . "\n";
    
    if ($rtaRequest->hasDeviceInfo()) {
        $deviceInfo = $rtaRequest->getDeviceInfo();
        $osType = $deviceInfo->getOsType() == RtaRequest_OsType::ANDROID ? 'Android' : 'iOS';
        echo "  操作系统: {$osType}\n";
        echo "  客户端版本: " . $deviceInfo->getAlipayClientVersion() . "\n";
        echo "  设备ID数量: " . count($deviceInfo->getDeviceId()) . "\n";
        
        foreach ($deviceInfo->getDeviceId() as $i => $deviceId) {
            $typeNames = [
                RtaRequest_IDType::IDFA_HASH => 'IDFA_HASH',
                RtaRequest_IDType::OAID_HASH => 'OAID_HASH',
                RtaRequest_IDType::CAID => 'CAID'
            ];
            $typeName = $typeNames[$deviceId->getType()] ?? 'UNKNOWN';
            echo "    [{$i}] 类型: {$typeName}, 值: " . substr($deviceId->getValue(), 0, 15) . "...\n";
            if ($deviceId->getVersion()) {
                echo "         版本: " . $deviceId->getVersion() . "\n";
            }
        }
    }
    
    if (count($rtaRequest->getRtaReqInfo()) > 0) {
        echo "  RTA请求信息:\n";
        foreach ($rtaRequest->getRtaReqInfo() as $i => $rtaReqInfo) {
            echo "    [{$i}] RTA ID: " . $rtaReqInfo->getRtaId() . ", 广告ID: " . $rtaReqInfo->getAdId() . "\n";
        }
    } else {
        echo "  RTA请求信息: 无 (新版本协议)\n";
    }
    
    // 序列化并发送请求
    $serializedRequest = $rtaRequest->serializeToString();
    echo "  序列化后大小: " . strlen($serializedRequest) . " bytes\n";
    
    echo "\n发送请求...\n";
    $startTime = microtime(true);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $serializedRequest,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-protobuf; charset=UTF-8',
            'Accept: application/x-protobuf'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $curlInfo = curl_getinfo($ch);
    
    curl_close($ch);
    
    $endTime = microtime(true);
    $totalTime = ($endTime - $startTime) * 1000;
    
    // 显示响应信息
    echo "响应详情:\n";
    echo "  HTTP状态码: {$httpCode}\n";
    echo "  总耗时: " . round($totalTime, 2) . "ms\n";
    echo "  网络耗时: " . round($curlInfo['total_time'] * 1000, 2) . "ms\n";
    
    if (!empty($error)) {
        echo "  CURL错误: {$error}\n";
        return false;
    }
    
    if ($httpCode !== 200) {
        echo "  HTTP错误，响应内容:\n";
        echo "    " . substr($response, 0, 300) . (strlen($response) > 300 ? '...' : '') . "\n";
        return false;
    }
    
    echo "  响应大小: " . strlen($response) . " bytes\n";
    
    // 解析响应
    try {
        $rtaResponse = new RtaResponse();
        $rtaResponse->mergeFromString($response);
        
        echo "\n✅ 响应解析成功:\n";
        echo "  返回码: " . $rtaResponse->getRetCode() . " (" . ($rtaResponse->getRetCode() === 0 ? '成功' : '失败') . ")\n";
        echo "  请求ID: " . $rtaResponse->getReqId() . "\n";
        echo "  返回消息: " . $rtaResponse->getRetMsg() . "\n";
        echo "  响应时间: " . date('Y-m-d H:i:s', $rtaResponse->getResponseTime() / 1000) . "\n";
        echo "  处理耗时: " . $rtaResponse->getProcessTimeMs() . "ms\n";
        echo "  RTA数据条数: " . count($rtaResponse->getRtaData()) . "\n";
        
        foreach ($rtaResponse->getRtaData() as $i => $rtaData) {
            echo "    [{$i}] RTA ID: " . $rtaData->getRtaReqInfo()->getRtaId();
            echo ", 参竞: " . ($rtaData->getIsBid() ? '是' : '否');
            if ($rtaData->getRtaReqInfo()->getAdId()) {
                echo ", 广告ID: " . $rtaData->getRtaReqInfo()->getAdId();
            }
            echo "\n";
            
            $extInfo = iterator_to_array($rtaData->getExtInfo());
            if (!empty($extInfo)) {
                echo "         扩展信息: " . json_encode($extInfo, JSON_UNESCAPED_UNICODE) . "\n";
            }
        }
        
        return $rtaResponse->getRetCode() === 0;
        
    } catch (Exception $e) {
        echo "  ❌ 解析响应失败: " . $e->getMessage() . "\n";
        echo "  响应前200字符: " . substr($response, 0, 200) . "\n";
        return false;
    }
}

// 主测试流程
$rtaUrl = 'http://ads.vivemall.com/alirta/rta_proxy_fixed.php';

echo "🚀 RTA 服务完整测试\n";
echo "目标地址: {$rtaUrl}\n";
echo "测试时间: " . date('Y-m-d H:i:s') . " (UTC)\n";
echo "版本: v1.0.1 (protobuf 修复版)\n";

$testResults = [];

// 测试用例
$testCases = [
    'ping' => 'Ping 连通性测试',
    'normal' => '标准 RTA 请求测试（包含 rta_req_info）',
    'no_rta_info' => '新版本 RTA 请求测试（不包含 rta_req_info）',
    'caid' => 'CAID 设备标识测试'
];

foreach ($testCases as $testType => $testDescription) {
    $request = createAlipayRequest($testType);
    $success = testRtaRequest($rtaUrl, $request, $testDescription);
    $testResults[$testType] = $success;
    
    // 每个测试之间暂停
    sleep(2);
}

// 测试总结
echo "\n" . str_repeat("=", 70) . "\n";
echo "🎯 测试总结\n";
echo str_repeat("=", 70) . "\n";

$passedCount = 0;
foreach ($testResults as $testType => $success) {
    $status = $success ? "✅ 通过" : "❌ 失败";
    echo sprintf("%-40s %s\n", $testCases[$testType], $status);
    if ($success) $passedCount++;
}

$passRate = round($passedCount / count($testResults) * 100, 1);
echo "\n通过率: {$passedCount}/" . count($testResults) . " ({$passRate}%)\n";

if ($passedCount === count($testResults)) {
    echo "\n🎉 所有测试通过！RTA 服务运行完美！\n";
    echo "\n✨ 服务已准备好接收支付宝的 protobuf 请求\n";
} elseif ($passedCount > 0) {
    echo "\n⚠️  部分测试通过，建议检查失败的测试项目。\n";
} else {
    echo "\n❌ 所有测试失败，请检查服务配置和日志。\n";
}

echo "\n📋 后续操作:\n";
echo "1. 查看详细日志: tail -f /tmp/rta_proxy.log\n";
echo "2. 监控服务状态: curl '{$rtaUrl}?health'\n";
echo "3. 配置实际的 token 映射关系\n";
echo "4. 在支付宝推广平台配置 RTA 回调地址: {$rtaUrl}\n";
echo "5. 进行生产环境测试\n";
?>