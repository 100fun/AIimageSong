<?php
/**
 * 简化的 RTA 服务测试工具
 * 直接发送二进制数据模拟 protobuf 请求
 */

/**
 * 创建模拟的 protobuf 数据
 */
function createMockProtobufData($type = 'normal') {
    switch ($type) {
        case 'ping':
            // 模拟一个简单的 ping 请求的 protobuf 数据
            return pack('H*', '1a24373830646561363937656136343832393436383039336136613634346134316464353661400140c0e0a5d7bb2f');
            
        case 'normal':
            // 模拟一个正常 RTA 请求的 protobuf 数据
            return pack('H*', '0a1332303838383032313233383434333536121a24373830646561363937656136343832393436383039336136613634346134316464353661400140c0e0a5d7bb2f320832014a0a6f6169645f686173685f746f5f6269645f31');
            
        default:
            return '';
    }
}

/**
 * 发送测试请求
 */
function sendTestRequest($url, $data, $testName) {
    echo "\n=== {$testName} ===\n";
    echo "发送时间: " . date('Y-m-d H:i:s') . "\n";
    echo "数据长度: " . strlen($data) . " bytes\n";
    
    $startTime = microtime(true);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-protobuf; charset=UTF-8',
            'Accept: application/x-protobuf'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
    
    curl_close($ch);
    
    $endTime = microtime(true);
    $processTime = ($endTime - $startTime) * 1000;
    
    echo "HTTP状态码: {$httpCode}\n";
    echo "总耗时: " . round($processTime, 2) . "ms\n";
    echo "网络耗时: " . round($totalTime, 2) . "ms\n";
    
    if (!empty($error)) {
        echo "CURL错误: {$error}\n";
        return false;
    }
    
    if ($httpCode !== 200) {
        echo "HTTP错误\n";
        echo "响应内容: " . substr($response, 0, 200) . "\n";
        return false;
    }
    
    echo "响应长度: " . strlen($response) . " bytes\n";
    
    if (strlen($response) > 0) {
        echo "响应前50字节(hex): " . bin2hex(substr($response, 0, 50)) . "\n";
        echo "✅ 收到有效响应\n";
    } else {
        echo "⚠️  收到空响应\n";
    }
    
    return true;
}

/**
 * 测试 JSON 格式请求（用于调试）
 */
function sendJsonTestRequest($url, $jsonData, $testName) {
    echo "\n=== {$testName} ===\n";
    echo "发送时间: " . date('Y-m-d H:i:s') . "\n";
    echo "JSON数据: " . $jsonData . "\n";
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json; charset=UTF-8',
            'Accept: application/json'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    echo "HTTP状态码: {$httpCode}\n";
    echo "响应: " . $response . "\n";
    
    return $httpCode === 200;
}

// 主测试
$rtaUrl = 'http://ads.vivemall.com/alirta/rta_proxy.php';

echo "RTA 服务简化测试\n";
echo "目标地址: {$rtaUrl}\n";
echo "测试时间: " . date('Y-m-d H:i:s') . "\n";

// 测试1: 空请求
echo "\n1. 测试空请求处理...";
sendTestRequest($rtaUrl, '', '空请求测试');

// 测试2: 模拟 ping 请求
echo "\n2. 测试模拟 Ping 请求...";
$pingData = createMockProtobufData('ping');
sendTestRequest($rtaUrl, $pingData, 'Ping 请求测试');

// 测试3: 模拟正常请求
echo "\n3. 测试模拟正常 RTA 请求...";
$normalData = createMockProtobufData('normal');
sendTestRequest($rtaUrl, $normalData, '正常 RTA 请求测试');

// 测试4: JSON 调试请求（仅用于调试，实际 RTA 不支持）
echo "\n4. 测试 JSON 格式请求（调试用）...";
$jsonData = json_encode([
    'userId' => '2088802123844356',
    'reqId' => '780dea69-7ea6-4829-a931-a6a44a1dd56a',
    'deviceInfo' => [
        'osType' => 'ANDROID',
        'deviceId' => [
            [
                'type' => 'OAID_HASH',
                'value' => 'oaid_hash_to_bid_1'
            ]
        ]
    ],
    'requestTime' => '1727254823059'
]);
sendJsonTestRequest($rtaUrl, $jsonData, 'JSON 调试请求');

echo "\n=== 测试完成 ===\n";
echo "建议查看日志获取详细信息: tail -f /tmp/rta_proxy.log\n";
?>