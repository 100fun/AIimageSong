<?php
/**
 * RTA 代理服务 - 修复版本
 * 支付宝推广平台 (protobuf) -> 本服务 -> 唯品会RTA服务 (JSON)
 */

// 引入 Composer 自动加载
require_once __DIR__ . '/vendor/autoload.php';

// 手动引入 protobuf 类文件
$protoFiles = [
    __DIR__ . '/proto/GPBMetadata/RtaV113.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaResponse.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaReqInfo.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaResponse_RtaData.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest_DeviceInfo.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest_DeviceID.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest_Geo.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest_IDType.php',
    __DIR__ . '/proto/Com/Alipay/Adbasiclib/Rta/Proto/RtaRequest_OsType.php'
];

foreach ($protoFiles as $file) {
    if (file_exists($file)) {
        require_once $file;
    }
}

use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaResponse;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaReqInfo;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaResponse_RtaData;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_DeviceInfo;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_DeviceID;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_Geo;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_IDType;
use Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest_OsType;

// 设置响应头
header('Content-Type: application/x-protobuf; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理 OPTIONS 预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 配置区域 - 请根据实际情况修改
const CONFIG = [
    'vip_rta_url' => 'https://d-rta.vtd.vip.com/rta/Isps_vip3/v1',
    'timeout' => 50,  // 请求超时时间（毫秒），留10ms缓冲
    'log_enabled' => true,
    'log_file' => '/tmp/rta_proxy.log',
    'token_mapping' => [
        // 支付宝rta_id -> 唯品会token映射，需要根据实际情况配置
        'rta_id_1' => 'ali_install',
        'rta_id_2' => 'ali_laxin', 
        'rta_id_3' => 'ali_lahuo',
        'default' => 'ali_install'
    ]
];

/**
 * 记录日志
 */
function writeLog($message, $level = 'INFO') {
    if (!CONFIG['log_enabled']) return;
    
    $timestamp = date('Y-m-d H:i:s.u');
    $logMessage = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    file_put_contents(CONFIG['log_file'], $logMessage, FILE_APPEND | LOCK_EX);
}

/**
 * 获取客户端IP
 */
function getClientIP() {
    $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ips = explode(',', $_SERVER[$key]);
            return trim($ips[0]);
        }
    }
    return 'unknown';
}

/**
 * 解析支付宝protobuf请求
 */
function parseAlipayRequest($rawData) {
    try {
        writeLog("开始解析protobuf请求，数据长度: " . strlen($rawData));
        
        $rtaRequest = new RtaRequest();
        $rtaRequest->mergeFromString($rawData);
        
        $requestData = [
            'req_id' => $rtaRequest->getReqId(),
            'user_id' => $rtaRequest->getUserId(),
            'one_id' => $rtaRequest->getOneId(),
            'request_time' => $rtaRequest->getRequestTime(),
            'is_ping' => $rtaRequest->getIsPing(),
            'device_info' => null,
            'rta_req_info' => []
        ];
        
        writeLog("基础字段解析完成: req_id=" . $requestData['req_id'] . ", user_id=" . $requestData['user_id']);
        
        // 处理设备信息
        if ($rtaRequest->hasDeviceInfo()) {
            $deviceInfo = $rtaRequest->getDeviceInfo();
            $requestData['device_info'] = [
                'os_type' => $deviceInfo->getOsType(),
                'device_id' => [],
                'geo' => null,
                'alipay_client_version' => $deviceInfo->getAlipayClientVersion()
            ];
            
            // 处理设备ID列表
            foreach ($deviceInfo->getDeviceId() as $deviceId) {
                $requestData['device_info']['device_id'][] = [
                    'type' => $deviceId->getType(),
                    'value' => $deviceId->getValue(),
                    'version' => $deviceId->getVersion()
                ];
            }
            
            writeLog("设备信息解析完成，设备ID数量: " . count($requestData['device_info']['device_id']));
            
            // 处理地理位置信息
            if ($deviceInfo->hasGeo()) {
                $geo = $deviceInfo->getGeo();
                $requestData['device_info']['geo'] = [
                    'city_code' => $geo->getCityCode(),
                    'longitude' => $geo->getLongitude(),
                    'latitude' => $geo->getLatitude()
                ];
            }
        }
        
        // 处理RTA请求信息
        foreach ($rtaRequest->getRtaReqInfo() as $rtaReqInfo) {
            $requestData['rta_req_info'][] = [
                'rta_id' => $rtaReqInfo->getRtaId(),
                'ad_id' => $rtaReqInfo->getAdId(),
                'ext_info' => iterator_to_array($rtaReqInfo->getExtInfo())
            ];
        }
        
        writeLog("RTA请求信息解析完成，条数: " . count($requestData['rta_req_info']));
        
        return $requestData;
        
    } catch (Exception $e) {
        writeLog("解析protobuf错误: " . $e->getMessage(), 'ERROR');
        writeLog("错误堆栈: " . $e->getTraceAsString(), 'ERROR');
        throw new Exception("Failed to parse protobuf request: " . $e->getMessage());
    }
}

/**
 * 转换设备ID类型：支付宝 -> 唯品会
 */
function convertDeviceIdType($alipayType) {
    $typeMapping = [
        0 => 4, // IDFA_HASH -> IDFA_MD5
        1 => 3, // OAID_HASH -> OAID_MD5  
        2 => 5  // CAID -> CAID
    ];
    
    return isset($typeMapping[$alipayType]) ? $typeMapping[$alipayType] : 0;
}

/**
 * 将支付宝请求转换为唯品会请求格式
 */
function convertToVipRequest($alipayRequest) {
    $vipRequest = [
        'v' => '1.0',
        'id' => $alipayRequest['req_id'],
        'adReqs' => []
    ];
    
    // 处理设备信息
    if (isset($alipayRequest['device_info']['device_id']) && !empty($alipayRequest['device_info']['device_id'])) {
        $deviceId = $alipayRequest['device_info']['device_id'][0];
        $vipRequest['didType'] = convertDeviceIdType($deviceId['type']);
        
        if ($vipRequest['didType'] == 5) { // CAID
            $vipRequest['caid1'] = $deviceId['value'];
            $vipRequest['caid1Version'] = $deviceId['version'] ?: '20230330';
        } else {
            $vipRequest['did'] = $deviceId['value'];
        }
    }
    
    // 处理ping请求
    if (isset($alipayRequest['is_ping']) && $alipayRequest['is_ping']) {
        $vipRequest['test'] = 1;
    }
    
    // 处理广告请求
    if (!empty($alipayRequest['rta_req_info'])) {
        foreach ($alipayRequest['rta_req_info'] as $rtaReqInfo) {
            $token = CONFIG['token_mapping'][$rtaReqInfo['rta_id']] ?? CONFIG['token_mapping']['default'];
            $vipRequest['adReqs'][] = [
                'token' => $token,
                'adId' => intval($rtaReqInfo['ad_id']) ?: 100001
            ];
        }
    } else {
        // 新版本：查询所有配置的rta_id
        foreach (CONFIG['token_mapping'] as $rtaId => $token) {
            if ($rtaId !== 'default') {
                $vipRequest['adReqs'][] = [
                    'token' => $token,
                    'adId' => 100001
                ];
            }
        }
        
        if (empty($vipRequest['adReqs'])) {
            $vipRequest['adReqs'][] = [
                'token' => CONFIG['token_mapping']['default'],
                'adId' => 100001
            ];
        }
    }
    
    return $vipRequest;
}

/**
 * 发送请求到唯品会RTA服务
 */
function sendToVipRTA($vipRequest) {
    $ch = curl_init();
    
    curl_setopt_array($ch, [
        CURLOPT_URL => CONFIG['vip_rta_url'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT_MS => CONFIG['timeout'],
        CURLOPT_CONNECTTIMEOUT_MS => 10,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Alipay-RTA-Proxy/1.0',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($vipRequest, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json; charset=UTF-8',
            'Accept: application/json'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
    
    curl_close($ch);
    
    if ($response === false || !empty($error)) {
        throw new Exception("CURL Error: " . $error);
    }
    
    return [
        'http_code' => $httpCode,
        'response' => $response,
        'total_time_ms' => $totalTime
    ];
}

/**
 * 根据token反向查找rta_id
 */
function findRtaIdByToken($token) {
    $reverseMapping = array_flip(CONFIG['token_mapping']);
    return $reverseMapping[$token] ?? $token;
}

/**
 * 将唯品会响应转换为支付宝protobuf格式
 */
function convertToAlipayResponse($vipResponse, $reqId, $processStartTime) {
    $vipData = json_decode($vipResponse, true);
    
    if (!$vipData) {
        throw new Exception("Invalid JSON response from VIP");
    }
    
    // 创建支付宝响应对象
    $rtaResponse = new RtaResponse();
    $rtaResponse->setRetCode(($vipData['errno'] == 0) ? 0 : 1);
    $rtaResponse->setReqId($reqId);
    $rtaResponse->setResponseTime(time() * 1000);
    $rtaResponse->setProcessTimeMs(round((microtime(true) - $processStartTime) * 1000));
    $rtaResponse->setRetMsg($vipData['msg'] ?? 'success');
    
    // 处理广告响应
    if (isset($vipData['bidResp']['adResps']) && is_array($vipData['bidResp']['adResps'])) {
        foreach ($vipData['bidResp']['adResps'] as $adResp) {
            $rtaData = new RtaResponse_RtaData();
            
            // 设置RTA请求信息
            $rtaReqInfo = new RtaReqInfo();
            $rtaId = findRtaIdByToken($adResp['token'] ?? 'default');
            $rtaReqInfo->setRtaId($rtaId);
            if (isset($adResp['adId'])) {
                $rtaReqInfo->setAdId(strval($adResp['adId']));
            }
            $rtaData->setRtaReqInfo($rtaReqInfo);
            
            // 设置是否参竞
            $rtaData->setIsBid($adResp['ac'] === 'y');
            
            // 处理推荐商品
            $extInfoMap = [];
            if (isset($adResp['products']) && is_array($adResp['products'])) {
                $extInfoMap['products'] = implode(',', $adResp['products']);
            }
            
            // 设置扩展信息
            foreach ($extInfoMap as $key => $value) {
                $rtaData->getExtInfo()[$key] = $value;
            }
            
            $rtaResponse->getRtaData()[] = $rtaData;
        }
    }
    
    return $rtaResponse;
}

/**
 * 处理ping请求
 */
function handlePingRequest($reqId) {
    $rtaResponse = new RtaResponse();
    $rtaResponse->setRetCode(0);
    $rtaResponse->setReqId($reqId);
    $rtaResponse->setResponseTime(time() * 1000);
    $rtaResponse->setProcessTimeMs(1);
    $rtaResponse->setRetMsg('pong');
    
    return $rtaResponse->serializeToString();
}

/**
 * 主处理函数
 */
function handleRequest() {
    $startTime = microtime(true);
    $clientIP = getClientIP();
    $alipayRequest = null;
    
    try {
        writeLog("收到RTA请求 - IP: {$clientIP}");
        
        // 获取原始请求数据
        $rawInput = file_get_contents('php://input');
        if (empty($rawInput)) {
            throw new Exception('Empty request body');
        }
        
        writeLog("请求数据长度: " . strlen($rawInput) . " bytes");
        
        // 解析支付宝protobuf请求
        $alipayRequest = parseAlipayRequest($rawInput);
        writeLog("解析支付宝请求成功 - req_id: " . $alipayRequest['req_id']);
        
        // 处理ping请求
        if (isset($alipayRequest['is_ping']) && $alipayRequest['is_ping']) {
            writeLog("处理ping请求");
            $response = handlePingRequest($alipayRequest['req_id']);
            echo $response;
            return;
        }
        
        // 转换为唯品会请求格式
        $vipRequest = convertToVipRequest($alipayRequest);
        writeLog("转换为唯品会请求: " . json_encode($vipRequest, JSON_UNESCAPED_UNICODE));
        
        // 发送到唯品会RTA服务
        $vipResponse = sendToVipRTA($vipRequest);
        writeLog("唯品会响应 - HTTP: {$vipResponse['http_code']}, 耗时: {$vipResponse['total_time_ms']}ms");
        writeLog("唯品会响应内容: " . $vipResponse['response']);
        
        if ($vipResponse['http_code'] !== 200) {
            throw new Exception("VIP RTA service returned HTTP {$vipResponse['http_code']}");
        }
        
        // 转换为支付宝响应格式
        $alipayResponse = convertToAlipayResponse(
            $vipResponse['response'], 
            $alipayRequest['req_id'], 
            $startTime
        );
        
        // 序列化并返回响应
        $responseData = $alipayResponse->serializeToString();
        
        http_response_code(200);
        echo $responseData;
        
        $totalTime = round((microtime(true) - $startTime) * 1000, 2);
        writeLog("请求完成 - 总耗时: {$totalTime}ms, 响应长度: " . strlen($responseData) . " bytes");
        
    } catch (Exception $e) {
        writeLog("错误: " . $e->getMessage(), 'ERROR');
        writeLog("错误堆栈: " . $e->getTraceAsString(), 'ERROR');
        
        // 返回错误响应
        $rtaResponse = new RtaResponse();
        $rtaResponse->setRetCode(1);
        $rtaResponse->setReqId(isset($alipayRequest['req_id']) ? $alipayRequest['req_id'] : 'unknown');
        $rtaResponse->setResponseTime(time() * 1000);
        $rtaResponse->setProcessTimeMs(round((microtime(true) - $startTime) * 1000));
        $rtaResponse->setRetMsg('Internal Server Error');
        
        http_response_code(200);
        echo $rtaResponse->serializeToString();
    }
}

/**
 * 健康检查
 */
function healthCheck() {
    header('Content-Type: application/json; charset=utf-8');
    
    $status = [
        'status' => 'ok',
        'timestamp' => date('Y-m-d H:i:s'),
        'version' => '1.0.1',
        'service' => 'Alipay-VIP RTA Proxy (Fixed)',
        'protobuf' => 'enabled',
        'classes' => [
            'RtaRequest' => class_exists('Com\Alipay\Adbasiclib\Rta\Proto\RtaRequest'),
            'RtaResponse' => class_exists('Com\Alipay\Adbasiclib\Rta\Proto\RtaResponse')
        ],
        'config' => [
            'vip_url' => CONFIG['vip_rta_url'],
            'timeout' => CONFIG['timeout'] . 'ms',
            'tokens' => array_keys(CONFIG['token_mapping'])
        ]
    ];
    
    echo json_encode($status, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

// 主程序入口
if (isset($_GET['health'])) {
    healthCheck();
} else {
    handleRequest();
}
?>