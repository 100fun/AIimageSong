#!/bin/bash

# RTA 性能优化执行脚本
# 用于测试和优化响应时间

echo "⚡ RTA 响应时间优化工具"
echo "目标: 从 203ms 优化到 < 100ms"
echo "======================================"

# 1. 运行性能分析
echo "📊 第一步: 性能分析"
php rta_performance_test.php

echo ""
echo "🔧 第二步: 应用优化建议"
echo "1. 替换现有的 rta_proxy.php 为 rta_proxy_optimized.php"
echo "2. 启用 PHP OPcache"
echo "3. 配置缓存系统"

read -p "是否要应用优化版本? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🚀 应用优化版本..."
    
    # 备份原文件
    if [ -f "rta_proxy.php" ]; then
        cp rta_proxy.php rta_proxy_backup_$(date +%Y%m%d_%H%M%S).php
        echo "✅ 原文件已备份"
    fi
    
    # 复制优化版本
    if [ -f "rta_proxy_optimized.php" ]; then
        cp rta_proxy_optimized.php rta_proxy.php
        echo "✅ 优化版本已应用"
    fi
    
    echo ""
    echo "🎯 第三步: 验证优化效果"
    php alipay_rta_vivemall_test.php
    
else
    echo "ℹ️ 优化建议已提供，您可以手动应用"
fi

echo ""
echo "📞 如需更多优化支持，请联系 100fun"