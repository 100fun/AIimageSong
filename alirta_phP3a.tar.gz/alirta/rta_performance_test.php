<?php
/**
 * RTA 响应时间专项测试工具
 * 专门测试和分析响应时间性能
 * 
 * 目标: 帮助将平均响应时间从 203ms 降低到 < 100ms
 */

class RtaPerformanceTest {
    
    private $baseUrl;
    private $testResults = [];
    private $detailedStats = [];
    
    public function __construct($url = 'https://ads.vivemall.com/alirta/rta_proxy.php') {
        $this->baseUrl = $url;
    }
    
    public function runPerformanceAnalysis() {
        $this->printHeader();
        
        // 1. 基准性能测试
        $this->runBaselineTest();
        
        // 2. 响应时间分布分析
        $this->analyzeResponseTimeDistribution();
        
        // 3. 网络延迟分析
        $this->analyzeNetworkLatency();
        
        // 4. 并发性能测试
        $this->analyzeConcurrentPerformance();
        
        // 5. 缓存效果测试
        $this->testCachePerformance();
        
        // 6. 生成优化建议
        $this->generateOptimizationRecommendations();
    }
    
    private function printHeader() {
        echo "⚡ RTA 响应时间专项性能测试\n";
        echo str_repeat("=", 60) . "\n";
        echo "🎯 目标: 将响应时间从 203ms 优化到 < 100ms\n";
        echo "📊 测试URL: {$this->baseUrl}\n";
        echo "⏰ 开始时间: " . date('Y-m-d H:i:s T') . "\n";
        echo str_repeat("=", 60) . "\n\n";
    }
    
    /**
     * 基准性能测试
     */
    private function runBaselineTest() {
        echo "📊 基准性能测试 (50次)\n";
        echo str_repeat("-", 40) . "\n";
        
        $times = [];
        $request = $this->buildTestRequest();
        
        for ($i = 0; $i < 50; $i++) {
            try {
                $startTime = microtime(true);
                $response = $this->makeRequest($request);
                $endTime = microtime(true);
                
                $responseTime = ($endTime - $startTime) * 1000;
                $times[] = $responseTime;
                
                if ($i % 10 === 0) {
                    echo "  进度: " . ($i + 1) . "/50 - 当前: " . round($responseTime, 2) . "ms\n";
                }
                
                usleep(50000); // 50ms间隔
                
            } catch (Exception $e) {
                echo "  测试 {$i} 失败: " . $e->getMessage() . "\n";
            }
        }
        
        if (!empty($times)) {
            $this->analyzeResponseTimes($times, '基准测试');
        }
        
        echo "\n";
    }
    
    /**
     * 响应时间分布分析
     */
    private function analyzeResponseTimeDistribution() {
        echo "📈 响应时间分布分析\n";
        echo str_repeat("-", 40) . "\n";
        
        $times = [];
        $request = $this->buildTestRequest();
        
        // 测试不同类型的请求
        $testTypes = [
            'ping' => $this->buildPingRequest(),
            'android' => $this->buildTestRequest('ANDROID'),
            'ios' => $this->buildTestRequest('IOS'),
            'large' => $this->buildLargeRequest()
        ];
        
        foreach ($testTypes as $type => $testRequest) {
            echo "  测试类型: {$type}\n";
            $typeTimes = [];
            
            for ($i = 0; $i < 20; $i++) {
                try {
                    $startTime = microtime(true);
                    $response = $this->makeRequest($testRequest);
                    $endTime = microtime(true);
                    
                    $responseTime = ($endTime - $startTime) * 1000;
                    $typeTimes[] = $responseTime;
                    
                } catch (Exception $e) {
                    // 忽略错误
                }
                
                usleep(25000); // 25ms间隔
            }
            
            if (!empty($typeTimes)) {
                $this->analyzeResponseTimes($typeTimes, "  {$type}请求");
                $this->detailedStats[$type] = $typeTimes;
            }
        }
        
        echo "\n";
    }
    
    /**
     * 网络延迟分析
     */
    private function analyzeNetworkLatency() {
        echo "🌐 网络延迟分析\n";
        echo str_repeat("-", 40) . "\n";
        
        $host = parse_url($this->baseUrl, PHP_URL_HOST);
        
        // DNS解析时间
        $dnsStart = microtime(true);
        $ip = gethostbyname($host);
        $dnsTime = (microtime(true) - $dnsStart) * 1000;
        
        echo "  DNS解析时间: " . round($dnsTime, 2) . "ms\n";
        
        // TCP连接时间
        $connectTimes = [];
        for ($i = 0; $i < 10; $i++) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $this->baseUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 5,
                CURLOPT_NOBODY => true
            ]);
            
            $startTime = microtime(true);
            curl_exec($ch);
            $endTime = microtime(true);
            
            $connectTime = curl_getinfo($ch, CURLINFO_CONNECT_TIME) * 1000;
            $totalTime = ($endTime - $startTime) * 1000;
            
            $connectTimes[] = $connectTime;
            
            curl_close($ch);
            usleep(100000); // 100ms间隔
        }
        
        if (!empty($connectTimes)) {
            $avgConnect = array_sum($connectTimes) / count($connectTimes);
            echo "  TCP连接时间: " . round($avgConnect, 2) . "ms (平均)\n";
            echo "  连接时间范围: " . round(min($connectTimes), 2) . "ms - " . round(max($connectTimes), 2) . "ms\n";
        }
        
        echo "\n";
    }
    
    /**
     * 并发性能分析
     */
    private function analyzeConcurrentPerformance() {
        echo "🔄 并发性能分析\n";
        echo str_repeat("-", 40) . "\n";
        
        $concurrencyLevels = [1, 2, 5, 10, 20];
        
        foreach ($concurrencyLevels as $concurrency) {
            echo "  并发级别: {$concurrency}\n";
            
            $times = [];
            $request = $this->buildTestRequest();
            
            $startTime = microtime(true);
            
            // 模拟并发请求
            for ($i = 0; $i < $concurrency; $i++) {
                try {
                    $reqStart = microtime(true);
                    $response = $this->makeRequest($request);
                    $reqEnd = microtime(true);
                    
                    $times[] = ($reqEnd - $reqStart) * 1000;
                    
                } catch (Exception $e) {
                    // 忽略错误
                }
            }
            
            $totalTime = (microtime(true) - $startTime) * 1000;
            
            if (!empty($times)) {
                $avgTime = array_sum($times) / count($times);
                $throughput = $concurrency / ($totalTime / 1000);
                
                echo "    平均响应时间: " . round($avgTime, 2) . "ms\n";
                echo "    总耗时: " . round($totalTime, 2) . "ms\n";
                echo "    吞吐量: " . round($throughput, 2) . " requests/sec\n";
                
                $this->detailedStats["concurrent_{$concurrency}"] = [
                    'avg_time' => $avgTime,
                    'total_time' => $totalTime,
                    'throughput' => $throughput
                ];
            }
            
            echo "\n";
        }
    }
    
    /**
     * 缓存效果测试
     */
    private function testCachePerformance() {
        echo "💾 缓存效果测试\n";
        echo str_repeat("-", 40) . "\n";
        
        $request = $this->buildTestRequest();
        
        // 第一次请求 (缓存未命中)
        echo "  首次请求 (缓存未命中):\n";
        $firstTimes = [];
        for ($i = 0; $i < 5; $i++) {
            try {
                $startTime = microtime(true);
                $response = $this->makeRequest($request);
                $endTime = microtime(true);
                
                $firstTimes[] = ($endTime - $startTime) * 1000;
                usleep(100000); // 100ms间隔
                
            } catch (Exception $e) {
                // 忽略错误
            }
        }
        
        if (!empty($firstTimes)) {
            $avgFirst = array_sum($firstTimes) / count($firstTimes);
            echo "    平均响应时间: " . round($avgFirst, 2) . "ms\n";
        }
        
        // 后续请求 (可能缓存命中)
        echo "  后续请求 (可能缓存命中):\n";
        $cachedTimes = [];
        for ($i = 0; $i < 10; $i++) {
            try {
                $startTime = microtime(true);
                $response = $this->makeRequest($request);
                $endTime = microtime(true);
                
                $cachedTimes[] = ($endTime - $startTime) * 1000;
                usleep(50000); // 50ms间隔
                
            } catch (Exception $e) {
                // 忽略错误
            }
        }
        
        if (!empty($cachedTimes)) {
            $avgCached = array_sum($cachedTimes) / count($cachedTimes);
            echo "    平均响应时间: " . round($avgCached, 2) . "ms\n";
            
            if (!empty($firstTimes)) {
                $improvement = round((($avgFirst - $avgCached) / $avgFirst) * 100, 1);
                echo "    缓存改善: " . $improvement . "%\n";
            }
        }
        
        echo "\n";
    }
    
    /**
     * 分析响应时间统计
     */
    private function analyzeResponseTimes($times, $label) {
        if (empty($times)) return;
        
        sort($times);
        $count = count($times);
        
        $min = min($times);
        $max = max($times);
        $avg = array_sum($times) / $count;
        $median = $times[intval($count / 2)];
        
        // 计算百分位数
        $p90 = $times[intval($count * 0.9)];
        $p95 = $times[intval($count * 0.95)];
        $p99 = $times[intval($count * 0.99)];
        
        echo "  📊 {$label} 统计:\n";
        echo "     最小值: " . round($min, 2) . "ms\n";
        echo "     最大值: " . round($max, 2) . "ms\n";
        echo "     平均值: " . round($avg, 2) . "ms\n";
        echo "     中位数: " . round($median, 2) . "ms\n";
        echo "     P90: " . round($p90, 2) . "ms\n";
        echo "     P95: " . round($p95, 2) . "ms\n";
        echo "     P99: " . round($p99, 2) . "ms\n";
        
        // 性能评级
        if ($avg < 50) {
            echo "     评级: 🟢 优秀\n";
        } elseif ($avg < 100) {
            echo "     评级: 🟡 良好\n";
        } elseif ($avg < 200) {
            echo "     评级: 🟠 可接受\n";
        } else {
            echo "     评级: 🔴 需要优化\n";
        }
    }
    
    /**
     * 生成优化建议
     */
    private function generateOptimizationRecommendations() {
        echo "💡 优化建议报告\n";
        echo str_repeat("=", 60) . "\n";
        
        // 分析当前性能瓶颈
        $recommendations = [];
        
        // 检查ping vs 正常请求的性能差异
        if (isset($this->detailedStats['ping']) && isset($this->detailedStats['android'])) {
            $pingAvg = array_sum($this->detailedStats['ping']) / count($this->detailedStats['ping']);
            $androidAvg = array_sum($this->detailedStats['android']) / count($this->detailedStats['android']);
            
            $processingTime = $androidAvg - $pingAvg;
            
            echo "🔍 性能分析:\n";
            echo "   Ping平均响应: " . round($pingAvg, 2) . "ms\n";
            echo "   正常请求平均: " . round($androidAvg, 2) . "ms\n";
            echo "   处理时间差异: " . round($processingTime, 2) . "ms\n\n";
            
            if ($processingTime > 100) {
                $recommendations[] = "🚀 **业务逻辑优化**: 处理时间差异较大(" . round($processingTime, 2) . "ms)，建议优化业务逻辑";
            }
            
            if ($pingAvg > 50) {
                $recommendations[] = "🌐 **网络优化**: Ping响应时间偏高(" . round($pingAvg, 2) . "ms)，建议优化网络层";
            }
        }
        
        // 并发性能分析
        if (isset($this->detailedStats['concurrent_1']) && isset($this->detailedStats['concurrent_10'])) {
            $single = $this->detailedStats['concurrent_1']['avg_time'];
            $concurrent = $this->detailedStats['concurrent_10']['avg_time'];
            
            if ($concurrent > $single * 1.5) {
                $recommendations[] = "⚡ **并发优化**: 高并发下性能下降明显，建议优化并发处理";
            }
        }
        
        // 通用优化建议
        $recommendations = array_merge($recommendations, [
            "💾 **启用缓存**: 实现响应缓存，可将重复请求响应时间降低到 < 10ms",
            "🔧 **启用OPcache**: PHP OPcache可以提升 20-30% 的执行性能",
            "📦 **优化Protobuf解析**: 使用更高效的protobuf解析，减少CPU时间",
            "🗃️ **数据库优化**: 如果涉及数据库操作，优化查询和连接池",
            "🚀 **异步处理**: 将非关键处理移到异步队列",
            "📊 **监控告警**: 建立响应时间监控，目标 < 100ms",
            "🔄 **负载均衡**: 使用负载均衡分散请求压力",
            "🎯 **代码热点优化**: 使用性能分析工具找出热点代码"
        ]);
        
        echo "💡 具体优化建议:\n\n";
        foreach ($recommendations as $i => $recommendation) {
            echo ($i + 1) . ". {$recommendation}\n";
        }
        
        echo "\n🎯 目标检查清单:\n";
        echo "   ☐ 平均响应时间 < 100ms\n";
        echo "   ☐ P95响应时间 < 150ms\n";
        echo "   ☐ Ping响应时间 < 30ms\n";
        echo "   ☐ 并发10的平均响应时间 < 120ms\n";
        echo "   ☐ 缓存命中率 > 50%\n";
        echo "   ☐ 错误率 < 0.1%\n";
        
        echo "\n📊 性能对比 (当前 vs 目标):\n";
        if (isset($this->detailedStats['android'])) {
            $currentAvg = array_sum($this->detailedStats['android']) / count($this->detailedStats['android']);
            $improvement = round((($currentAvg - 100) / $currentAvg) * 100, 1);
            echo "   当前平均响应时间: " . round($currentAvg, 2) . "ms\n";
            echo "   目标响应时间: < 100ms\n";
            echo "   需要改善: " . $improvement . "%\n";
        }
        
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📞 技术支持: 如需详细优化方案，请联系 100fun\n";
        echo "🔗 GitHub: https://github.com/100fun/AIimageSong/tree/master/ad-rta-test\n";
        echo str_repeat("=", 60) . "\n";
    }
    
    // 辅助方法
    private function buildTestRequest($osType = 'ANDROID') {
        // 构建标准测试请求
        $data = '';
        
        // user_id
        $userId = '2088802123844356';
        $data .= "\x0a" . chr(strlen($userId)) . $userId;
        
        // req_id
        $reqId = uniqid('perf_test_', true);
        $data .= "\x1a" . chr(strlen($reqId)) . $reqId;
        
        // request_time
        $requestTime = round(microtime(true) * 1000);
        $timeBytes = '';
        while ($requestTime > 0) {
            $byte = $requestTime & 0x7F;
            $requestTime >>= 7;
            if ($requestTime > 0) $byte |= 0x80;
            $timeBytes .= chr($byte);
        }
        $data .= "\x38" . $timeBytes;
        
        // is_ping = false
        $data .= "\x40\x00";
        
        return $data;
    }
    
    private function buildPingRequest() {
        $data = '';
        
        // user_id
        $userId = '2088802123844356';
        $data .= "\x0a" . chr(strlen($userId)) . $userId;
        
        // req_id
        $reqId = uniqid('ping_test_', true);
        $data .= "\x1a" . chr(strlen($reqId)) . $reqId;
        
        // request_time
        $requestTime = round(microtime(true) * 1000);
        $timeBytes = '';
        while ($requestTime > 0) {
            $byte = $requestTime & 0x7F;
            $requestTime >>= 7;
            if ($requestTime > 0) $byte |= 0x80;
            $timeBytes .= chr($byte);
        }
        $data .= "\x38" . $timeBytes;
        
        // is_ping = true
        $data .= "\x40\x01";
        
        return $data;
    }
    
    private function buildLargeRequest() {
        $data = $this->buildTestRequest();
        
        // 添加大量设备ID信息来测试大数据处理
        for ($i = 0; $i < 10; $i++) {
            $deviceInfo = '';
            $deviceInfo .= "\x12\x07ANDROID"; // osType
            
            $deviceId = '';
            $deviceId .= "\x08\x01"; // type = OAID_HASH
            $deviceIdValue = 'large_test_device_id_' . $i . '_' . str_repeat('x', 20);
            $deviceId .= "\x12" . chr(strlen($deviceIdValue)) . $deviceIdValue;
            
            $deviceInfo .= "\x1a" . chr(strlen($deviceId)) . $deviceId;
            $data .= "\x32" . chr(strlen($deviceInfo)) . $deviceInfo;
        }
        
        return $data;
    }
    
    private function makeRequest($data) {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->baseUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-protobuf; charset=UTF-8',
                'User-Agent: RtaPerformanceTest/1.0'
            ],
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception("HTTP请求错误: " . $error);
        }
        
        if ($httpCode !== 200) {
            throw new Exception("HTTP状态码错误: " . $httpCode);
        }
        
        return $response;
    }
}

// 执行性能测试
if (php_sapi_name() === 'cli') {
    echo "🚀 启动 RTA 响应时间专项测试\n\n";
    
    $url = $argv[1] ?? 'https://ads.vivemall.com/alirta/rta_proxy.php';
    $tester = new RtaPerformanceTest($url);
    $tester->runPerformanceAnalysis();
    
} else {
    header('Content-Type: text/plain; charset=utf-8');
    
    $url = $_GET['url'] ?? 'https://ads.vivemall.com/alirta/rta_proxy.php';
    $tester = new RtaPerformanceTest($url);
    $tester->runPerformanceAnalysis();
}

?>