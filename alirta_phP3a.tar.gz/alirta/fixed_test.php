<?php
/**
 * 自动检测 protobuf 类的测试脚本
 */

// 引入 Composer 自动加载
require_once __DIR__ . '/vendor/autoload.php';

// 自动检测可用的 protobuf 类
function detectProtobufClasses() {
    $classes = [];
    
    // 检查生成的类文件
    $protoDir = __DIR__ . '/proto';
    if (is_dir($protoDir)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($protoDir));
        
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $content = file_get_contents($file->getPathname());
                
                // 提取类名和命名空间
                if (preg_match('/namespace\s+([^;]+);/', $content, $nsMatches) &&
                    preg_match('/class\s+(\w+)/', $content, $classMatches)) {
                    
                    $namespace = $nsMatches[1];
                    $className = $classMatches[1];
                    $fullClassName = $namespace . '\\' . $className;
                    
                    $classes[$className] = $fullClassName;
                }
            }
        }
    }
    
    return $classes;
}

/**
 * 创建 protobuf 请求（使用动态类检测）
 */
function createDynamicProtobufRequest($classes) {
    try {
        if (!isset($classes['RtaRequest'])) {
            throw new Exception("RtaRequest 类未找到");
        }
        
        $rtaRequestClass = $classes['RtaRequest'];
        $rtaRequest = new $rtaRequestClass();
        
        // 设置基本字段
        if (method_exists($rtaRequest, 'setUserId')) {
            $rtaRequest->setUserId('2088802123844356');
        }
        if (method_exists($rtaRequest, 'setReqId')) {
            $rtaRequest->setReqId('780dea69-7ea6-4829-a931-a6a44a1dd56a');
        }
        if (method_exists($rtaRequest, 'setRequestTime')) {
            $rtaRequest->setRequestTime(time() * 1000);
        }
        if (method_exists($rtaRequest, 'setIsPing')) {
            $rtaRequest->setIsPing(false);
        }
        
        return $rtaRequest;
        
    } catch (Exception $e) {
        echo "创建 protobuf 请求失败: " . $e->getMessage() . "\n";
        return null;
    }
}

/**
 * 发送请求并解析响应
 */
function sendAndParseRequest($url, $rtaRequest, $classes) {
    echo "发送 protobuf 请求...\n";
    
    try {
        $serializedData = $rtaRequest->serializeToString();
        echo "序列化数据长度: " . strlen($serializedData) . " bytes\n";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $serializedData,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-protobuf; charset=UTF-8'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        echo "HTTP 状态码: {$httpCode}\n";
        
        if (!empty($error)) {
            echo "CURL 错误: {$error}\n";
            return false;
        }
        
        if ($httpCode !== 200) {
            echo "HTTP 错误\n";
            return false;
        }
        
        echo "响应长度: " . strlen($response) . " bytes\n";
        
        // 尝试解析响应
        if (isset($classes['RtaResponse'])) {
            $rtaResponseClass = $classes['RtaResponse'];
            $rtaResponse = new $rtaResponseClass();
            
            try {
                $rtaResponse->mergeFromString($response);
                echo "成功解析响应:\n";
                
                if (method_exists($rtaResponse, 'getRetCode')) {
                    echo "  返回码: " . $rtaResponse->getRetCode() . "\n";
                }
                if (method_exists($rtaResponse, 'getReqId')) {
                    echo "  请求ID: " . $rtaResponse->getReqId() . "\n";
                }
                if (method_exists($rtaResponse, 'getRetMsg')) {
                    echo "  返回消息: " . $rtaResponse->getRetMsg() . "\n";
                }
                if (method_exists($rtaResponse, 'getProcessTimeMs')) {
                    echo "  处理耗时: " . $rtaResponse->getProcessTimeMs() . "ms\n";
                }
                
                return true;
            } catch (Exception $e) {
                echo "解析响应失败: " . $e->getMessage() . "\n";
                echo "响应前100字符: " . substr($response, 0, 100) . "\n";
                return false;
            }
        }
        
        return true;
        
    } catch (Exception $e) {
        echo "发送请求失败: " . $e->getMessage() . "\n";
        return false;
    }
}

// 主程序
echo "RTA 服务动态 protobuf 测试\n";
echo "==========================\n";

$rtaUrl = 'http://ads.vivemall.com/alirta/rta_proxy.php';

// 1. 检测可用的 protobuf 类
echo "1. 检测 protobuf 类...\n";
$classes = detectProtobufClasses();

if (empty($classes)) {
    echo "❌ 未找到任何 protobuf 类\n";
    echo "请检查 proto 目录和类生成是否正确\n";
    exit(1);
}

echo "✅ 找到 " . count($classes) . " 个 protobuf 类:\n";
foreach ($classes as $className => $fullClassName) {
    echo "  - {$className}: {$fullClassName}\n";
}

// 2. 创建测试请求
echo "\n2. 创建测试请求...\n";
$rtaRequest = createDynamicProtobufRequest($classes);

if (!$rtaRequest) {
    echo "❌ 无法创建测试请求\n";
    exit(1);
}

echo "✅ 成功创建测试请求\n";

// 3. 发送请求并解析响应
echo "\n3. 发送请求到: {$rtaUrl}\n";
$success = sendAndParseRequest($rtaUrl, $rtaRequest, $classes);

if ($success) {
    echo "\n✅ 测试成功！RTA 服务工作正常\n";
} else {
    echo "\n❌ 测试失败，请检查日志\n";
}

echo "\n查看详细日志: tail -f /tmp/rta_proxy.log\n";
?>